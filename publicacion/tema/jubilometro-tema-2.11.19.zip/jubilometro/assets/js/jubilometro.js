/* ==========================================================================
   JUBILÓMETRO · Interacciones globales (sin dependencias)
   Cabecera fija, menú móvil, buscador, índice y progreso de lectura, compartir,
   lecturas del mes, tabla de datos, botón de cookies y los efectos 3D (tarjetas,
   portada y transiciones entre páginas).
   ========================================================================== */
(function () {
  'use strict';
  function safe(fn) { try { fn(); } catch (e) { if (window.console) console.warn(e); } }
  var $ = function (s, c) { return (c || document).querySelector(s); };
  var $$ = function (s, c) { return Array.prototype.slice.call((c || document).querySelectorAll(s)); };

  // Cabecera: sombra al hacer scroll (IntersectionObserver, sin escuchar el scroll)
  function initHeader() {
    var h = $('[data-jm-header]'), s = $('[data-jm-sentinel]');
    if (!h || !s || !('IntersectionObserver' in window)) return;
    new IntersectionObserver(function (e) { h.classList.toggle('is-stuck', !e[0].isIntersecting); }).observe(s);
  }

  // Cajón móvil
  function initDrawer() {
    var d = $('#jm-drawer'); if (!d) return;
    var openers = $$('[data-jm-drawer-open]'), last = null;
    function set(open) {
      d.classList.toggle('is-open', open);
      d.setAttribute('aria-hidden', open ? 'false' : 'true');
      openers.forEach(function (b) { b.setAttribute('aria-expanded', open ? 'true' : 'false'); });
      document.documentElement.style.overflow = open ? 'hidden' : '';
      if (open) { last = document.activeElement; var f = $('[data-jm-drawer-close]', d); if (f) f.focus(); } else if (last) last.focus();
    }
    openers.forEach(function (b) { b.addEventListener('click', function () { set(true); }); });
    $$('[data-jm-drawer-close]', d).forEach(function (b) { b.addEventListener('click', function () { set(false); }); });
    d.addEventListener('click', function (e) { if (e.target === d) set(false); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && d.classList.contains('is-open')) set(false); });
  }

  // Buscador (diálogo nativo)
  function initSearch() {
    var dlg = $('#jm-search'); if (!dlg || !dlg.showModal) return;
    $$('[data-jm-search-open]').forEach(function (b) {
      b.addEventListener('click', function () { dlg.showModal(); var i = $('input', dlg); if (i) setTimeout(function () { i.focus(); }, 30); });
    });
    $$('[data-jm-search-close]', dlg).forEach(function (b) { b.addEventListener('click', function () { dlg.close(); }); });
    dlg.addEventListener('click', function (e) { if (e.target === dlg) dlg.close(); });
  }

  // Formularios del prototipo (en WordPress los gestiona Kadence Blocks Form o tu proveedor de newsletter)
  function initForms() {
    $$('form[data-jm-demo]').forEach(function (f) {
      f.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!f.checkValidity()) { f.reportValidity(); return; }
        var box = f.closest('[data-jm-sent]') || f; box.classList.add('is-sent');
        var ok = $('.jm-form-ok, .jm-nl__ok', box); if (ok) { ok.setAttribute('tabindex', '-1'); ok.focus(); }
      });
    });
  }

  // Botón "Configurar cookies": reabre la CMP de Google (Privacidad y mensajes de AdSense).
  // Las calculadoras y las páginas legales no cargan AdSense ni su aviso: allí el botón lleva a la
  // portada con #configurar-cookies, que abre el aviso en cuanto se carga.
  function initCookies() {
    function abrir() {
      window.googlefc = window.googlefc || {}; window.googlefc.callbackQueue = window.googlefc.callbackQueue || [];
      window.googlefc.callbackQueue.push(function () { if (window.googlefc.showRevocationMessage) window.googlefc.showRevocationMessage(); });
    }
    var conAviso = !!document.querySelector('script[src*="adsbygoogle"]');
    if (conAviso && location.hash === '#configurar-cookies') {
      abrir();
      try { history.replaceState(null, '', location.pathname + location.search); } catch (e) { /* sin historial */ }
    }
    $$('[data-jm-cookies]').forEach(function (b) {
      b.addEventListener('click', function () {
        if (conAviso) abrir(); else location.href = '/#configurar-cookies';
      });
    });
  }

  // Página de datos: ordenar, filtrar por comunidad, buscar y descargar CSV
  function initDatos() {
    var root = $('[data-jm-datos]'); if (!root) return;
    var table = $('table', root), tbody = $('tbody', table), rows = $$('tr', tbody);
    var q = $('[data-jm-q]', root), cc = $('[data-jm-ccaa]', root), count = $('[data-jm-count]', root);
    function apply() {
      var t = (q && q.value || '').trim().toLowerCase(), c = cc && cc.value, n = 0;
      rows.forEach(function (r) {
        var ok = (!t || r.getAttribute('data-name').indexOf(t) > -1) && (!c || r.getAttribute('data-ccaa') === c);
        r.hidden = !ok; if (ok) n++;
      });
      if (count) count.textContent = n + (n === 1 ? ' provincia' : ' provincias');
    }
    if (q) q.addEventListener('input', apply);
    if (cc) cc.addEventListener('change', apply);
    $$('th[data-sort] button', table).forEach(function (btn) {
      btn.addEventListener('click', function () {
        var th = btn.parentNode, key = th.getAttribute('data-sort'), dir = th.getAttribute('aria-sort') === 'descending' ? 'ascending' : 'descending';
        $$('th[data-sort]', table).forEach(function (o) { o.removeAttribute('aria-sort'); });
        th.setAttribute('aria-sort', dir);
        rows.sort(function (a, b) {
          var x = a.getAttribute('data-' + key), y = b.getAttribute('data-' + key);
          var nx = parseFloat(x), ny = parseFloat(y);
          var r = isNaN(nx) ? x.localeCompare(y, 'es') : nx - ny;
          return dir === 'ascending' ? r : -r;
        });
        rows.forEach(function (r) { tbody.appendChild(r); });
      });
    });
    var dl = $('[data-jm-csv]', root);
    if (dl) dl.addEventListener('click', function () {
      var lines = [['provincia', 'comunidad', 'pensiones_jubilacion', 'pension_media_jubilacion_eur', 'diferencia_media_nacional_eur']];
      rows.forEach(function (r) { lines.push([r.getAttribute('data-label'), r.getAttribute('data-ccaa-label'), r.getAttribute('data-num') || '', r.getAttribute('data-valor'), r.getAttribute('data-dif')]); });
      var csv = lines.map(function (l) { return l.map(function (v) { return '"' + String(v).replace(/"/g, '""') + '"'; }).join(';'); }).join('\n');
      var a = document.createElement('a');
      a.href = URL.createObjectURL(new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' }));
      a.download = 'pension-media-provincia.csv'; document.body.appendChild(a); a.click(); a.remove();
    });
  }

  // Artículo: índice con la sección activa resaltada
  function initToc() {
    var links = $$('.jm-post__aside .jm-toc a[href^="#"]'); if (!links.length || !('IntersectionObserver' in window)) return;
    var map = {};
    links.forEach(function (a) { var el = document.getElementById(decodeURIComponent(a.getAttribute('href').slice(1))); if (el) map[el.id] = a; });
    var current = null;
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (e) { if (e.isIntersecting) current = e.target.id; });
      if (current && map[current]) { links.forEach(function (a) { a.classList.remove('is-active'); }); map[current].classList.add('is-active'); }
    }, { rootMargin: '-15% 0px -70% 0px', threshold: 0 });
    Object.keys(map).forEach(function (id) { io.observe(document.getElementById(id)); });
  }

  // Barra de progreso de lectura (solo si el navegador no la anima por CSS)
  function initProgress() {
    var bar = $('.jm-progress'); if (!bar) return;
    if (window.CSS && CSS.supports && CSS.supports('animation-timeline: scroll()')) return;
    var ticking = false;
    function draw() { var h = document.documentElement, max = h.scrollHeight - h.clientHeight; bar.style.transform = 'scaleX(' + (max > 0 ? Math.min(1, h.scrollTop / max) : 0) + ')'; ticking = false; }
    window.addEventListener('scroll', function () { if (!ticking) { ticking = true; requestAnimationFrame(draw); } }, { passive: true });
    draw();
  }

  // Compartir: copiar el enlace
  function initShare() {
    $$('[data-jm-copy]').forEach(function (b) {
      b.addEventListener('click', function () {
        var url = b.getAttribute('data-jm-copy'), label = b.getAttribute('aria-label'), span = $('span', b), txt = span && span.textContent;
        function done() {
          b.classList.add('is-done'); b.setAttribute('aria-label', 'Enlace copiado'); if (span) span.textContent = '¡Copiado!';
          setTimeout(function () { b.classList.remove('is-done'); b.setAttribute('aria-label', label); if (span) span.textContent = txt; }, 2200);
        }
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(url).then(done, function () { window.prompt('Copia el enlace:', url); });
        else window.prompt('Copia el enlace:', url);
      });
    });
  }

  // Calculadoras para otras webs: copiar el código de inserción
  function initCopyCode() {
    $$('[data-jm-copycode]').forEach(function (b) {
      var box = $(b.getAttribute('data-jm-copycode')), txt = b.textContent;
      if (!box) return;
      b.addEventListener('click', function () {
        function done() { b.classList.add('is-done'); b.textContent = '¡Código copiado!'; setTimeout(function () { b.classList.remove('is-done'); b.textContent = txt; }, 2500); }
        function manual() { box.focus(); box.select(); }
        if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(box.value).then(done, manual);
        else manual();
      });
    });
  }

  // Estadísticas propias, sin cookies ni datos personales (inc/estadisticas.php): una señal por página vista
  // (de dónde llega la visita y si se queda a leer) y otra por botón pulsado. Cuenta también para «Lo más leído».
  // Dirección con la que se llegó (con sus utm_): initStats las quita de la barra y Analytics la necesita entera
  var urlInicial = location.href;
  function beacon(o) {
    if (!navigator.sendBeacon) return;
    var fd = new FormData(); Object.keys(o).forEach(function (k) { fd.append(k, o[k]); });
    try { navigator.sendBeacon('/wp-admin/admin-ajax.php', fd); } catch (e) {}
  }
  function track(ev) {
    var p = ev.split(':'); beacon({ action: 'jm_ev', e: p[0], k: p[1] || '' });
    if (gaOn) window.gtag('event', p[0], { jm_detalle: p[1] || '' }); // el mismo botón, también en Analytics
  }

  // Google Analytics 4 (functions.php deja el ID en window.jmGA). Usa cookies, así que solo se carga
  // con permiso del aviso de privacidad de Google: finalidades 1 (almacenar en el dispositivo) y 8
  // (medir el contenido) del TCF y el proveedor Google (755), o cuando el RGPD no se aplica. Si se
  // retira el permiso, deja de guardar cookies. Sin aviso en la página (calculadoras, legales), nada.
  var gaOn = false;
  function initAnalytics() {
    var id = window.jmGA, intentos = 0;
    if (!id || !/^G-[A-Z0-9]{6,14}$/.test(id)) return;
    function cargar() {
      if (gaOn) { window.gtag('consent', 'update', { analytics_storage: 'granted' }); return; }
      gaOn = true;
      window.dataLayer = window.dataLayer || [];
      window.gtag = function () { window.dataLayer.push(arguments); };
      window.gtag('consent', 'default', { analytics_storage: 'granted', ad_storage: 'denied', ad_user_data: 'denied', ad_personalization: 'denied' });
      window.gtag('js', new Date());
      window.gtag('config', id, { page_location: urlInicial, allow_google_signals: false, allow_ad_personalization_signals: false });
      var sc = document.createElement('script'); sc.async = true;
      sc.src = 'https://www.googletagmanager.com/gtag/js?id=' + encodeURIComponent(id);
      document.head.appendChild(sc);
    }
    (function esperar() {
      if (typeof window.__tcfapi === 'function') {
        window.__tcfapi('addEventListener', 2, function (tc, ok) {
          if (!ok || !tc || (tc.eventStatus !== 'tcloaded' && tc.eventStatus !== 'useractioncomplete')) return;
          var pc = tc.purpose && tc.purpose.consents, vc = tc.vendor && tc.vendor.consents;
          if (tc.gdprApplies === false || (pc && pc[1] && pc[8] && vc && vc[755])) cargar();
          else if (gaOn) window.gtag('consent', 'update', { analytics_storage: 'denied' });
        });
      } else if (++intentos < 20) { setTimeout(esperar, 500); }
    })();
  }
  function initStats() {
    var b = document.body, q = new URLSearchParams(location.search), r = '', sent = false, t0;
    try { r = document.referrer ? new URL(document.referrer).hostname : ''; } catch (e) {}
    var touch = window.matchMedia && matchMedia('(pointer: coarse)').matches;
    var d = { action: 'jm_hit', id: b.getAttribute('data-jm-id') || '0', r: r && r === location.hostname ? '=' : r,
      s: q.get('utm_source') || '', c: q.get('utm_campaign') || '', w: !touch ? 'd' : (Math.min(screen.width, screen.height) < 600 ? 'm' : 't') };
    if (b.classList.contains('error404')) d.p = location.pathname;
    function send() { if (sent) return; sent = true; d.l = Date.now() - t0 >= 4000 ? 1 : 0; beacon(d); }
    function start() {
      t0 = Date.now();
      setTimeout(send, 4000);
      addEventListener('pagehide', send);
      document.addEventListener('visibilitychange', function () { if (document.visibilityState === 'hidden') send(); });
    }
    // Una página que el navegador prepara por adelantado no cuenta hasta que se abre de verdad
    if (document.prerendering) document.addEventListener('prerenderingchange', start, { once: true }); else start();
    // Las etiquetas utm_ ya están anotadas: fuera de la barra de direcciones (si alguien copia el enlace, va limpio)
    if (/[?&]utm_/.test(location.search) && history.replaceState) {
      ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term'].forEach(function (k) { q.delete(k); });
      var qs = q.toString();
      history.replaceState(history.state, '', location.pathname + (qs ? '?' + qs : '') + location.hash);
    }
    // Botones con data-jm-ev (compartir, seguir…), uso de las calculadoras y altas en la newsletter
    document.addEventListener('click', function (e) {
      var t = e.target.closest && e.target.closest('[data-jm-ev]'); if (t) track(t.getAttribute('data-jm-ev'));
      t = e.target.closest && e.target.closest('[data-jm-listen], [data-jm-print], [data-jm-fs-set]');
      if (t) track('herramienta:' + (t.hasAttribute('data-jm-listen') ? 'escuchar' : t.hasAttribute('data-jm-print') ? 'imprimir' : 'letra'));
    });
    var calcs = {};
    document.addEventListener('submit', function (e) {
      var f = e.target; if (!f || !f.closest) return;
      if (f.matches('.jm-nl__form')) { track('newsletter:alta'); return; }
      if (!f.matches('form[data-jm-calc], [data-jm-sim] form, .calc-jubi form')) return;
      var m = location.pathname.match(/^\/calculadoras\/([a-z0-9-]+)\/$/), k = m ? m[1] : 'guia';
      if (!calcs[k]) { calcs[k] = 1; track('calculadora:' + k); } // una vez por página, aunque se recalcule
    }, true);
  }

  // Compartir con el menú del propio móvil (WhatsApp, Telegram, SMS…) donde el navegador lo permite
  function initNativeShare() {
    if (!navigator.share) return;
    $$('[data-jm-native]').forEach(function (b) {
      b.hidden = false;
      b.addEventListener('click', function () { navigator.share({ title: b.getAttribute('data-jm-title'), url: b.getAttribute('data-jm-native') }).catch(function () {}); });
    });
  }

  // «Seguir leyendo»: la libreta recuerda la última guía que abriste (solo en tu navegador).
  // Guardar algo en el dispositivo sin que el lector lo pida necesita su permiso (art. 22.2 LSSI):
  // se usa la elección del aviso de privacidad de Google (finalidad 1 del TCF, «almacenar información
  // en el dispositivo»). Sin aviso o sin permiso no se guarda nada y se borra lo guardado antes.
  function initResume() {
    var post = $('[data-jm-view]'), box = $('[data-jm-resume]'), key = 'jm_ultima_guia';
    if (!post && !box) return;
    try {
      if (box) {
        var d = JSON.parse(localStorage.getItem(key) || 'null');
        if (d && d.u && d.t) { var a = $('a', box) || box.appendChild(document.createElement('a')); a.href = d.u; a.textContent = d.t; box.classList.add('is-on'); }
      }
    } catch (e) { /* sin almacenamiento: no pasa nada */ }
    function aplicar(permiso) {
      try {
        if (!permiso) { localStorage.removeItem(key); if (box) box.classList.remove('is-on'); return; }
        var h = post && $('.jm-post__title h1');
        if (h) localStorage.setItem(key, JSON.stringify({ t: h.textContent.trim(), u: location.pathname }));
      } catch (e) { /* sin almacenamiento */ }
    }
    var intentos = 0;
    (function esperar() {
      if (typeof window.__tcfapi === 'function') {
        window.__tcfapi('addEventListener', 2, function (tc, ok) {
          if (!ok || !tc || (tc.eventStatus !== 'tcloaded' && tc.eventStatus !== 'useractioncomplete')) return;
          aplicar(tc.gdprApplies === false || !!(tc.purpose && tc.purpose.consents && tc.purpose.consents[1]));
        });
      } else if (++intentos < 20) { setTimeout(esperar, 500); }
    })();
  }

  /* ---------- Movimiento (nunca con "reducir movimiento") ---------- */
  var calm = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  var fine = window.matchMedia && window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  // Tarjetas en 3D: se inclinan hacia el ratón con un brillo y un filo de luz (solo con ratón).
  // Un único oyente para toda la página; la tarjeta vuelve a su sitio al salir.
  // [lo que se vigila, lo que se inclina (vacío: la propia tarjeta)]
  var TILT = [
    ['.jm-cajon, .jm-tema, .jm-saldo__row, .jm-life__card, .jm-next, .jm-card, .jm-person, .jm-pagehead__media', ''],
    ['.jm-story:not(.jm-story--lead)', '.jm-story__media']
  ];
  function initTilt() {
    if (calm || !fine) return;
    var watch = TILT.map(function (t) { return t[0]; }).join(', '), st = null, raf = 0;
    function frame() {
      raf = 0; if (!st) return;
      var el = st.el, r = el.getBoundingClientRect();
      if (r.width && r.height) {
        st.tx = Math.max(-1, Math.min(1, ((st.cx - r.left) / r.width) * 2 - 1));
        st.ty = Math.max(-1, Math.min(1, ((st.cy - r.top) / r.height) * 2 - 1));
      }
      st.x += (st.tx - st.x) * 0.2; st.y += (st.ty - st.y) * 0.2;
      var a = st.amp;
      el.style.transform = 'perspective(' + st.p + 'px) rotateX(' + (-st.y * a).toFixed(2) + 'deg) rotateY(' + (st.x * a).toFixed(2) + 'deg) translate3d(0,' + st.lift + 'px,0)';
      el.style.setProperty('--gx', ((st.x + 1) * 50).toFixed(1) + '%');
      el.style.setProperty('--gy', ((st.y + 1) * 50).toFixed(1) + '%');
      el.style.setProperty('--px', st.x.toFixed(3));
      el.style.setProperty('--py', st.y.toFixed(3));
      if (Math.abs(st.tx - st.x) + Math.abs(st.ty - st.y) > 0.004) raf = requestAnimationFrame(frame);
    }
    function release(s) {
      var el = s.el; el.classList.remove('is-tilt'); el.style.transform = '';
      ['--gx', '--gy', '--px', '--py'].forEach(function (k) { el.style.removeProperty(k); });
      if (s.card !== el) s.card.classList.remove('is-tilting');
    }
    function engage(card, e) {
      var target = card, sub = '';
      for (var i = 0; i < TILT.length; i++) { if (card.matches(TILT[i][0])) { sub = TILT[i][1]; break; } }
      if (sub) { target = $(sub, card); if (!target) return null; card.classList.add('is-tilting'); }
      var r = target.getBoundingClientRect(), big = Math.max(r.width, r.height * 1.3);
      target.classList.add('is-tilt');
      return { el: target, card: card, x: 0, y: 0, tx: 0, ty: 0, cx: e.clientX, cy: e.clientY, amp: Math.max(1.5, Math.min(6, 2700 / big)), p: Math.max(800, Math.round(big * 2.4)), lift: sub ? -2 : -4 };
    }
    document.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      var card = e.target.closest ? e.target.closest(watch) : null;
      if (!st || card !== st.card) {
        if (st) release(st);
        st = card ? engage(card, e) : null;
      }
      if (!st) return;
      st.cx = e.clientX; st.cy = e.clientY;
      if (!raf) raf = requestAnimationFrame(frame);
    }, { passive: true });
    document.documentElement.addEventListener('pointerleave', function () { if (st) { release(st); st = null; } });
  }

  // Portada: la guía destacada, en un escenario 3D que sigue al ratón, con un foco de luz en el fondo
  function initStage() {
    var mast = $('.jm-mast'), stage = $('.jm-mast__stage');
    if (!mast || !stage || calm || !fine) return;
    var spot = $('.jm-mast__spot', mast), x = 0, y = 0, tx = 0, ty = 0, sx = 0, sy = 0, tsx = 0, tsy = 0, cx = 0, cy = 0, raf = 0;
    function loop() {
      raf = 0;
      var r = stage.getBoundingClientRect(), m = mast.getBoundingClientRect();
      if (mast.classList.contains('is-lit')) {
        tx = Math.max(-1, Math.min(1, (cx - (r.left + r.width / 2)) / (r.width / 2 + 240)));
        ty = Math.max(-1, Math.min(1, (cy - (r.top + r.height / 2)) / (r.height / 2 + 240)));
        tsx = cx - m.left; tsy = cy - m.top;
      }
      x += (tx - x) * 0.08; y += (ty - y) * 0.08; sx += (tsx - sx) * 0.16; sy += (tsy - sy) * 0.16;
      stage.style.setProperty('--px', x.toFixed(3));
      stage.style.setProperty('--py', y.toFixed(3));
      if (spot) spot.style.transform = 'translate3d(' + sx.toFixed(1) + 'px,' + sy.toFixed(1) + 'px,0)';
      if (Math.abs(tx - x) + Math.abs(ty - y) > 0.002 || Math.abs(tsx - sx) + Math.abs(tsy - sy) > 0.5) raf = requestAnimationFrame(loop);
    }
    mast.addEventListener('pointermove', function (e) {
      if (e.pointerType && e.pointerType !== 'mouse') return;
      cx = e.clientX; cy = e.clientY;
      if (!mast.classList.contains('is-lit')) {
        // El foco aparece donde está el ratón, sin cruzar la cabecera desde una esquina
        var m = mast.getBoundingClientRect(); sx = tsx = cx - m.left; sy = tsy = cy - m.top;
        mast.classList.add('is-lit');
      }
      if (!raf) raf = requestAnimationFrame(loop);
    }, { passive: true });
    mast.addEventListener('pointerleave', function () { mast.classList.remove('is-lit'); tx = ty = 0; if (!raf) raf = requestAnimationFrame(loop); });
  }

  // Grabado de billete antiguo (guilloché) detrás de la portada y de las cabeceras de página.
  // Se dibuja en un lienzo; con ratón, las líneas se desplazan y hacen aguas como el papel moneda.
  function initGuilloche() {
    var heads = $$('.jm-mast, .jm-pagehead').concat(window.innerWidth >= 1100 ? $$('.jm-post__head') : []);
    if (!heads.length || !window.HTMLCanvasElement) return;
    heads.forEach(function (box) {
      var cv = $('.jm-guilloche', box);
      if (!cv) { cv = document.createElement('canvas'); cv.className = 'jm-guilloche'; cv.setAttribute('aria-hidden', 'true'); box.insertBefore(cv, box.firstChild); }
      var ctx = cv.getContext('2d'); if (!ctx) return;
      var focus = $('.jm-mast__stage, .jm-pagehead__media', box), big = box.classList.contains('jm-mast'), small = box.classList.contains('jm-post__head');
      var w = 0, h = 0, dpr = 1, cx = 0, cy = 0, R = 0, ph = 0, py = 0, tph = 0, tpy = 0, raf = 0, job = 0;
      function curve(i) {
        var k = (i / 24) * Math.PI * 2;
        ctx.strokeStyle = i % 2 ? 'rgba(29,78,216,.15)' : 'rgba(30,58,138,.17)';
        ctx.beginPath();
        for (var j = 0; j <= 300; j++) {
          var t = (j / 300) * Math.PI * 2, r = R + 30 * Math.sin(7 * t + k + ph) + 14 * Math.cos(12 * t - 2 * k + py);
          if (j) ctx.lineTo(cx + r * Math.cos(t), cy + r * Math.sin(t)); else ctx.moveTo(cx + r, cy);
        }
        ctx.stroke();
      }
      function band() {
        for (var n = 0; n < 7; n++) {
          ctx.strokeStyle = n % 2 ? 'rgba(30,58,138,.2)' : 'rgba(29,78,216,.16)';
          ctx.beginPath();
          for (var x = 0; x <= w + 8; x += 4) {
            var y = h - 22 + 7 * Math.sin(x * 0.021 + n * 0.55 + ph) + 4 * Math.sin(x * 0.049 - n * 0.9 + py);
            if (x) ctx.lineTo(x, y); else ctx.moveTo(x, y);
          }
          ctx.stroke();
        }
      }
      function clear() { ctx.setTransform(dpr, 0, 0, dpr, 0, 0); ctx.clearRect(0, 0, w, h); ctx.lineWidth = 0.75; }
      function draw() { clear(); for (var i = 0; i < 24; i++) curve(i); if (big) band(); }
      // Primer dibujo en tandas de 4 curvas por fotograma: la página no se queda esperando
      function drawSoft() {
        cancelAnimationFrame(job); clear(); var i = 0;
        (function step() { var end = Math.min(24, i + 4); for (; i < end; i++) curve(i); if (i < 24) job = requestAnimationFrame(step); else if (big) band(); })();
      }
      // Medidas: se toman cuando el navegador ya ha colocado la página (sin forzarle a recalcular)
      function measure() {
        var b = box.getBoundingClientRect(); if (!b.width) return;
        var f = focus && focus.getBoundingClientRect();
        // En pantallas táctiles, a resolución normal: son líneas muy tenues y así pesa la mitad
        dpr = fine ? Math.min(window.devicePixelRatio || 1, 2) : 1; w = b.width; h = b.height;
        cv.width = Math.round(w * dpr); cv.height = Math.round(h * dpr);
        if (f && f.width) { cx = f.left - b.left + f.width / 2; cy = f.top - b.top + f.height / 2; R = Math.min(Math.hypot(f.width, f.height) / 2 + (big ? 30 : 18), 460); }
        else { cx = w * 0.8; cy = h * 0.45; R = Math.min(h * 0.55, 240); }
        if (small) { cx = w - 170; cy = Math.min(h * 0.4, 190); R = Math.min(h * 0.38, 140); }
        drawSoft();
      }
      if ('ResizeObserver' in window) {
        var lw = 0, lh = 0;
        new ResizeObserver(function (es) {
          var r = es[0].contentRect;
          if (Math.abs(r.width - lw) < 1 && Math.abs(r.height - lh) < 1) return;
          lw = r.width; lh = r.height; measure();
        }).observe(box);
      } else window.addEventListener('load', measure);
      if (calm || !fine) return;
      function loop() {
        raf = 0; ph += (tph - ph) * 0.08; py += (tpy - py) * 0.08; draw();
        if (Math.abs(tph - ph) + Math.abs(tpy - py) > 0.002) raf = requestAnimationFrame(loop);
      }
      box.addEventListener('pointermove', function (e) {
        if (!w || (e.pointerType && e.pointerType !== 'mouse')) return;
        var b = box.getBoundingClientRect();
        tph = ((e.clientX - b.left) / b.width - 0.5) * 2.4; tpy = ((e.clientY - b.top) / b.height - 0.5) * 2;
        if (!raf) { cancelAnimationFrame(job); raf = requestAnimationFrame(loop); }
      }, { passive: true });
    });
  }

  // Fotos que se revelan: llegan en sepia y toman color al entrar en pantalla, como en el cuarto oscuro
  function initDevelop() {
    var fotos = $$('.jm-story__media, .jm-life__media, .jm-pagehead__media, .jm-tile__media, .jm-post__hero, .jm-nl__media');
    if (!fotos.length) return;
    if (calm || !('IntersectionObserver' in window)) { fotos.forEach(function (f) { f.classList.add('is-dev'); }); return; }
    var io = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting) { e.target.classList.add('is-dev'); io.unobserve(e.target); } });
    }, { threshold: 0.3 });
    fotos.forEach(function (f) { io.observe(f); });
    window.addEventListener('beforeprint', function () { fotos.forEach(function (f) { f.classList.add('is-dev'); }); });
  }

  // En el móvil, las tarjetas se hunden un poco al tocarlas (Safari solo lo muestra si la página escucha los toques)
  function initPress() {
    if (!fine) document.addEventListener('touchstart', function () {}, { passive: true });
  }

  // Al abrir una guía desde su tarjeta, la foto viaja hasta la cabecera de la guía
  // (navegadores con transiciones entre páginas; en el resto se navega como siempre)
  function initMorph() {
    if (calm || !('onpageswap' in window)) return;
    var CARD = '.jm-story, .jm-cajon, .jm-card, .jm-life__card', named = [];
    function reset() { named.forEach(function (el) { el.style.viewTransitionName = ''; }); named = []; }
    window.addEventListener('pageswap', function (e) {
      reset();
      if (!e.viewTransition || !e.activation || !e.activation.entry) return;
      var url = e.activation.entry.url.split('#')[0], hero = $('.jm-post__hero img');
      if (hero) { hero.style.viewTransitionName = 'none'; named.push(hero); }
      var link = $$('a[href]').filter(function (a) { return a.href.split('#')[0] === url && a.closest(CARD) && $('img', a.closest(CARD)); })[0];
      if (!link) return;
      var img = $('img', link.closest(CARD)), r = img.getBoundingClientRect();
      if (r.bottom <= 0 || r.top >= window.innerHeight) return;
      img.style.viewTransitionName = 'jm-foto'; named.push(img);
    });
    window.addEventListener('pageshow', function (e) { if (e.persisted) reset(); });
  }

  // Los bloques que aún no se ven aparecen al llegar a ellos (lo visible al cargar no se toca).
  // La primera respuesta del observador dice qué está fuera de pantalla, sin obligar al navegador a medir la página.
  function initReveal() {
    // Desactivado (tema 2.7.1): el contenido se ve al instante al bajar, sin esperar animaciones
    return;
    if (calm || !('IntersectionObserver' in window)) return;
    var sel = '.jm-figures__head, .jm-rail__head, .jm-duo__head, .jm-rail__grid > .jm-story, .jm-rail__list > .jm-story, .jm-mostread .jm-ledger, .jm-upcoming__box, .jm-toolband__copy, .jm-passbook, .jm-section-head, .jm-life__card, .jm-tile, .jm-updates__intro, .jm-timeline > li, .jm-method > *, .jm-nl, .jm-authorbox, .jm-post__foot .jm-story, .jm-cajonera > *, .jm-front__latest > .jm-ledger, .jm-saldo__row, .jm-temas__top, .jm-tema, .jm-card, .jm-principles > li, .jm-next';
    var els = $$(sel);
    if (!els.length) return;
    var pending = [], timer = 0;
    function show(el) {
      var k = pending.indexOf(el);
      if (k < 0) return;
      pending.splice(k, 1); io.unobserve(el);
      var d = parseInt(el.style.getPropertyValue('--rv-d'), 10) || 0;
      el.classList.add('is-in');
      // Al terminar, se retiran las clases para no frenar la inclinación ni otros efectos
      setTimeout(function () { el.classList.remove('jm-rv', 'is-in'); el.style.removeProperty('--rv-d'); }, 1150 + d);
    }
    var io = new IntersectionObserver(function (entries) {
      var h = window.innerHeight;
      entries.forEach(function (en) {
        var el = en.target;
        if (!el.jmSeen) {
          el.jmSeen = true;
          var b = en.boundingClientRect, skipped = !b.width && !b.height; // sección aún sin maquetar (content-visibility)
          // Visible (o ya pasado) al cargar: se queda como está
          if (en.isIntersecting || (!skipped && b.top < h)) { io.unobserve(el); return; }
          var i = el.parentElement ? Array.prototype.indexOf.call(el.parentElement.children, el) : 0;
          el.style.setProperty('--rv-d', Math.min(i, 5) * 70 + 'ms');
          el.classList.add('jm-rv');
          pending.push(el);
          return;
        }
        if (en.isIntersecting) show(el);
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0 });
    els.forEach(function (el) { io.observe(el); });
    // Red de seguridad: si el observador no avisa, lo que ya está en pantalla (o se ha pasado) se muestra igual
    // (las secciones que el navegador aún no ha maquetado se saltan: preguntar por ellas obligaría a maquetarlas)
    function sweep() {
      timer = 0; var h = window.innerHeight;
      pending.slice().forEach(function (el) {
        if (el.checkVisibility && !el.checkVisibility({ contentVisibilityAuto: true })) return;
        var r = el.getBoundingClientRect();
        if ((r.width || r.height) && r.top < h) show(el);
      });
    }
    window.addEventListener('scroll', function () { if (pending.length && !timer) timer = setTimeout(sweep, 120); }, { passive: true });
    // Al imprimir, todo visible
    window.addEventListener('beforeprint', function () { pending.slice().forEach(show); });
  }

  // El saldo de 2026: las cifras ruedan como un contador al llegar a ellas.
  // Al terminar se devuelve el HTML original (el texto nunca cambia: sin efecto en Google ni en lectores de pantalla).
  function initRoll() {
    return; // Desactivado (tema 2.7.1): las cifras se ven quietas desde el principio
    var box = $('.jm-saldo');
    if (calm || !box || !('IntersectionObserver' in window)) return;
    var first = new IntersectionObserver(function (e) {
      first.disconnect();
      var b = e[0].boundingClientRect, skipped = !b.width && !b.height; // aún sin maquetar: está más abajo
      if (e[0].isIntersecting || (!skipped && b.top < window.innerHeight)) return; // ya se ve: quieto
      armRoll(box);
    });
    first.observe(box);
  }
  function armRoll(box) {
    var vals = $$('.jm-saldo__v', box), orig = vals.map(function (v) { return v.innerHTML; });
    vals.forEach(function (v, r) {
      var i = 0, texts = [], w = document.createTreeWalker(v, 4, null), t;
      v.style.setProperty('--r', r);
      while ((t = w.nextNode())) { if (t.nodeValue.trim()) texts.push(t); }
      texts.forEach(function (tn) {
        var frag = document.createDocumentFragment();
        tn.nodeValue.split('').forEach(function (ch) {
          if (ch === ' ') { frag.appendChild(document.createTextNode(' ')); return; }
          var s = document.createElement('span'); s.className = 'jm-ch'; s.style.setProperty('--i', i++); s.textContent = ch; frag.appendChild(s);
        });
        tn.parentNode.replaceChild(frag, tn);
      });
    });
    box.classList.add('is-armed');
    var io = new IntersectionObserver(function (e) {
      if (!e[0].isIntersecting) return;
      io.disconnect(); box.classList.add('is-rolled');
      setTimeout(function () { vals.forEach(function (v, k) { v.innerHTML = orig[k]; }); box.classList.remove('is-armed', 'is-rolled'); }, 2200);
    }, { rootMargin: '0px 0px -10% 0px' });
    io.observe(box);
  }

  /* ---------- Herramientas de lectura (guías) ---------- */
  // Tamaño de letra: normal, grande o muy grande. Se recuerda en este navegador.
  function initFontSize() {
    var btns = $$('[data-jm-fs-set]'); if (!btns.length) return;
    var root = document.documentElement;
    function paint() { var cur = root.getAttribute('data-jm-fs') || ''; btns.forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-jm-fs-set') === cur)); }); }
    btns.forEach(function (b) {
      b.addEventListener('click', function () {
        var v = b.getAttribute('data-jm-fs-set');
        if (v) root.setAttribute('data-jm-fs', v); else root.removeAttribute('data-jm-fs');
        try { if (v) localStorage.setItem('jm_fs', v); else localStorage.removeItem('jm_fs'); } catch (e) { /* sin almacenamiento */ }
        paint();
      });
    });
    paint();
  }

  // Escuchar la guía: lectura en voz alta (voz en español del propio dispositivo), resaltando el párrafo.
  // Se lee frase a frase: así no se corta en los navegadores que detienen las lecturas largas.
  function initListen() {
    var btn = $('[data-jm-listen]'), stopBtn = $('[data-jm-listen-stop]'), prose = $('.jm-prose');
    if (!btn) return;
    // El botón viene visible (sin saltos al cargar); solo se retira si el navegador no sabe leer en voz alta
    if (!stopBtn || !prose || !('speechSynthesis' in window) || typeof window.SpeechSynthesisUtterance === 'undefined') { btn.hidden = true; return; }
    var synth = window.speechSynthesis, voice = null, blocks = [], bi = 0, parts = [], pi = 0, state = 'idle', current = null;
    var label = $('span', btn), icon = $('use', btn);
    function pickVoice() {
      var vs = synth.getVoices() || [];
      voice = vs.filter(function (v) { return /^es[-_]ES/i.test(v.lang); })[0] || vs.filter(function (v) { return /^es/i.test(v.lang); })[0] || null;
    }
    pickVoice();
    if ('onvoiceschanged' in synth) synth.addEventListener('voiceschanged', pickVoice);
    btn.hidden = false;
    function ui(s) {
      state = s;
      label.textContent = s === 'playing' ? 'Pausar' : s === 'paused' ? 'Seguir escuchando' : 'Escuchar la guía';
      if (icon) icon.setAttribute('href', s === 'playing' ? '#i-pause' : '#i-volume');
      btn.setAttribute('aria-pressed', String(s === 'playing'));
      stopBtn.hidden = s === 'idle';
    }
    function mark(el) {
      if (current) current.classList.remove('is-speaking');
      current = el;
      if (!el) return;
      el.classList.add('is-speaking');
      var r = el.getBoundingClientRect();
      if (r.top < 90 || r.bottom > window.innerHeight - 40) el.scrollIntoView({ block: 'center', behavior: calm ? 'auto' : 'smooth' });
    }
    function collect() {
      var head = $$('.jm-post__title h1, .jm-post__dek');
      blocks = head.concat($$('h2, h3, p, li, .jm-answer__title', prose).filter(function (el) {
        return el.offsetParent !== null && el.textContent.trim().length > 1 && !el.closest('table, .jm-toc, .jm-sources, .jm-ad, .jm-faq, .jm-share, figure, .jm-calc-cta, li li');
      }));
    }
    // Frases: se corta solo en un signo seguido de espacio (así «3.359,60 €» o «2,81 %» se leen enteros);
    // las frases muy largas se parten en las comas.
    function sentences(t) {
      var s = t.replace(/\s+/g, ' ').trim(), out = [], re = /[.!?;:]\s+/g, last = 0, m;
      while ((m = re.exec(s))) { out.push(s.slice(last, m.index + 1)); last = re.lastIndex; }
      out.push(s.slice(last));
      var res = [];
      out.forEach(function (x) {
        x = x.trim(); if (!x) return;
        while (x.length > 220) {
          var cut = x.lastIndexOf(', ', 200);
          if (cut < 60) break;
          res.push(x.slice(0, cut + 1)); x = x.slice(cut + 2);
        }
        res.push(x);
      });
      return res;
    }
    function next() {
      if (state !== 'playing') return;
      if (pi >= parts.length) {
        bi++; pi = 0;
        if (bi >= blocks.length) { stop(); return; }
        parts = sentences(blocks[bi].textContent); mark(blocks[bi]);
      }
      var u = new window.SpeechSynthesisUtterance(parts[pi]);
      u.lang = 'es-ES'; if (voice) u.voice = voice; u.rate = 0.95;
      u.onend = function () { pi++; next(); };
      u.onerror = function (e) { if (e.error !== 'interrupted' && e.error !== 'canceled') { pi++; next(); } };
      synth.speak(u);
    }
    function play() {
      if (!blocks.length) collect();
      if (!blocks.length) return;
      if (state === 'idle') { bi = 0; pi = 0; }
      parts = sentences(blocks[bi].textContent); mark(blocks[bi]);
      synth.cancel(); ui('playing'); next();
    }
    function pause() { ui('paused'); synth.cancel(); }
    function stop() { synth.cancel(); ui('idle'); bi = 0; pi = 0; mark(null); }
    btn.addEventListener('click', function () { if (state === 'playing') pause(); else play(); });
    stopBtn.addEventListener('click', stop);
    window.addEventListener('pagehide', function () { synth.cancel(); });
  }

  // Imprimir la guía (con una hoja limpia: sin menús, anuncios ni botones)
  function initPrint() {
    $$('[data-jm-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });
    // En papel, las preguntas frecuentes salen desplegadas; al terminar vuelven como estaban
    var opened = [];
    window.addEventListener('beforeprint', function () { opened = $$('.jm-prose details:not([open])'); opened.forEach(function (d) { d.open = true; }); });
    window.addEventListener('afterprint', function () { opened.forEach(function (d) { d.open = false; }); opened = []; });
  }

  /* ---------- Buscador instantáneo: resultados mientras escribes ---------- */
  // Página «Guías»: buscador que filtra las guías al escribir y, en cada tema, solo las 6 primeras
  // con un botón para ver el resto (en el móvil la lista completa ocupaba decenas de pantallas).
  function initGuideFilter() {
    var topics = $$('.jm-topic'); if (topics.length < 3 || !$('.jm-topic__list')) return;
    var MAX = 6, norm = function (s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
    var total = 0;
    topics.forEach(function (t) {
      var list = $('.jm-topic__list', t); if (!list) return;
      var items = $$(':scope > li', list); total += items.length;
      items.forEach(function (li) { li.setAttribute('data-jm-txt', norm(li.textContent)); });
      if (items.length <= MAX) return;
      items.forEach(function (li, i) { if (i >= MAX) li.classList.add('is-extra'); });
      var h = $('h2', t), nombre = h ? h.textContent.trim() : '';
      if (nombre !== nombre.toUpperCase()) nombre = nombre.toLowerCase(); // «IMSERSO» se queda en mayúsculas
      var btn = document.createElement('button');
      btn.type = 'button'; btn.className = 'jm-btn jm-btn--ghost jm-topic__more';
      btn.setAttribute('aria-expanded', 'false');
      btn.textContent = 'Ver las ' + items.length + ' guías de ' + nombre;
      btn.addEventListener('click', function () {
        var open = list.classList.toggle('is-open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        btn.textContent = open ? 'Ver menos' : 'Ver las ' + items.length + ' guías de ' + nombre;
      });
      list.insertAdjacentElement('afterend', btn);
    });
    var box = document.createElement('div');
    box.className = 'jm-guidefilter';
    box.innerHTML = '<label class="jm-guidefilter__l" for="jm-gf">Busca entre las ' + total + ' guías</label>' +
      '<input class="jm-input" id="jm-gf" type="search" autocomplete="off" placeholder="Ej.: viudedad, IMSERSO, policía">' +
      '<p class="jm-guidefilter__n" aria-live="polite"></p>';
    topics[0].parentNode.insertBefore(box, topics[0]);
    var input = $('input', box), out = $('.jm-guidefilter__n', box), timer;
    input.addEventListener('input', function () {
      clearTimeout(timer);
      timer = setTimeout(function () {
        var q = norm(input.value.trim()), n = 0, words = q.split(/\s+/).filter(Boolean);
        document.body.classList.toggle('is-filtering', !!q);
        topics.forEach(function (t) {
          var vis = 0;
          $$('.jm-topic__list > li', t).forEach(function (li) {
            var ok = !words.length || words.every(function (w) { return li.getAttribute('data-jm-txt').indexOf(w) > -1; });
            li.hidden = !ok; if (ok) vis++;
          });
          t.hidden = !!q && vis === 0; n += vis;
        });
        out.innerHTML = !q ? '' : n ? n + (n === 1 ? ' guía encontrada' : ' guías encontradas') :
          'No hay ninguna guía con esas palabras. Prueba con otra o usa el <a href="/?s=' + encodeURIComponent(input.value.trim()) + '">buscador</a>.';
      }, 120);
    });
  }

  // Portada, «Novedades del BOE»: en el móvil se ven las tres últimas y un botón para el resto
  // (el CSS solo pliega la lista y muestra el botón por debajo de 640 px)
  function initTimelineMore() {
    var list = $('.jm-timeline'); if (!list) return;
    var n = $$(':scope > li', list).length; if (n <= 3) return;
    var btn = document.createElement('button');
    btn.type = 'button'; btn.className = 'jm-btn jm-btn--ghost jm-timeline__more';
    btn.setAttribute('aria-expanded', 'false');
    btn.textContent = 'Ver las ' + n + ' novedades';
    btn.addEventListener('click', function () {
      var open = list.classList.toggle('is-open');
      btn.setAttribute('aria-expanded', open ? 'true' : 'false');
      btn.textContent = open ? 'Ver menos' : 'Ver las ' + n + ' novedades';
      if (!open) btn.scrollIntoView({ block: 'nearest' });
    });
    list.insertAdjacentElement('afterend', btn);
  }

  function initLiveSearch() {
    var inputs = $$('#jm-s, #mast-s'); if (!inputs.length || !window.fetch) return;
    var index = null, loading = null;
    var norm = function (s) { return (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, ''); };
    function load() {
      if (index) return Promise.resolve(index);
      if (!loading) {
        loading = fetch('/wp-json/jm/v1/indice', { credentials: 'omit' }).then(function (r) { return r.ok ? r.json() : []; }).then(function (d) {
          index = (d || []).map(function (x) { x.h = norm(x.t + ' ' + x.c + ' ' + x.e); x.ht = norm(x.t); return x; });
          return index;
        }).catch(function () { index = []; return index; });
      }
      return loading;
    }
    function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
    // Resalta las palabras buscadas (sin tildes ni mayúsculas) marcando tramos del título original
    function hl(t, words) {
      var n = norm(t), marks = [], out = '', pos = 0;
      if (n.length !== t.length) return esc(t);
      words.forEach(function (w) { if (w.length < 2) return; var k = n.indexOf(w); if (k > -1) marks.push([k, k + w.length]); });
      marks.sort(function (a, b) { return a[0] - b[0]; }).forEach(function (m) {
        if (m[0] < pos) return;
        out += esc(t.slice(pos, m[0])) + '<mark>' + esc(t.slice(m[0], m[1])) + '</mark>';
        pos = m[1];
      });
      return out + esc(t.slice(pos));
    }
    inputs.forEach(function (input) {
      var form = input.form; if (!form) return;
      var box = document.createElement('div');
      box.className = 'jm-sugg' + (input.id === 'mast-s' ? ' jm-sugg--drop' : '');
      box.id = input.id + '-res'; box.hidden = true;
      box.setAttribute('role', 'listbox'); box.setAttribute('aria-label', 'Resultados');
      form.parentNode.insertBefore(box, form.nextSibling);
      var status = document.createElement('p'); status.className = 'jm-sr'; status.setAttribute('aria-live', 'polite');
      box.parentNode.insertBefore(status, box.nextSibling);
      input.setAttribute('aria-controls', box.id); input.setAttribute('aria-autocomplete', 'list');
      var t = 0, active = -1;
      function links() { return $$('a', box); }
      function move(d) {
        var ls = links(); if (!ls.length) return;
        active = (active + d + ls.length) % ls.length;
        ls.forEach(function (a, i) { a.classList.toggle('is-active', i === active); a.setAttribute('aria-selected', String(i === active)); });
        ls[active].scrollIntoView({ block: 'nearest' });
      }
      function render() {
        var q = norm(input.value).trim();
        active = -1;
        if (q.length < 2) { box.hidden = true; box.innerHTML = ''; status.textContent = ''; return; }
        load().then(function (ix) {
          var words = q.split(/\s+/).filter(Boolean);
          var res = ix.map(function (x) {
            var s = 0;
            for (var i = 0; i < words.length; i++) {
              var w = words[i];
              if (x.h.indexOf(w) < 0) return null;
              s += x.ht.indexOf(w) === 0 ? 6 : x.ht.indexOf(' ' + w) >= 0 ? 4 : x.ht.indexOf(w) >= 0 ? 3 : 1;
            }
            if (x.k === 'calc') s += 0.5;
            return { x: x, s: s };
          }).filter(Boolean).sort(function (a, b) { return b.s - a.s; }).slice(0, 7);
          if (!res.length) {
            box.innerHTML = '<p class="jm-sugg__none">No hay guías con esas palabras. Pulsa <b>Buscar</b> para buscar en toda la web.</p>';
            status.textContent = 'Sin resultados';
          } else {
            box.innerHTML = res.map(function (r) {
              var x = r.x, meta = esc(x.c);
              return '<a role="option" aria-selected="false" href="' + esc(x.u) + '"><span class="jm-sugg__t">' + hl(x.t, words) + '</span><span class="jm-sugg__m">' + meta + '</span></a>';
            }).join('') + '<button type="button" class="jm-sugg__all">Ver todos los resultados de «' + esc(input.value.trim()) + '»</button>';
            status.textContent = res.length + (res.length === 1 ? ' resultado' : ' resultados');
          }
          box.hidden = false;
          var all = $('.jm-sugg__all', box);
          if (all) all.addEventListener('click', function (e) { e.preventDefault(); form.submit(); });
        });
      }
      input.addEventListener('focus', load, { once: true });
      input.addEventListener('input', function () { clearTimeout(t); t = setTimeout(render, 110); });
      input.addEventListener('keydown', function (e) {
        if (box.hidden) return;
        if (e.key === 'ArrowDown') { e.preventDefault(); move(1); }
        else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
        else if (e.key === 'Enter' && active > -1) { e.preventDefault(); links()[active].click(); }
        else if (e.key === 'Escape' && input.id === 'mast-s') { box.hidden = true; }
      });
      document.addEventListener('click', function (e) { if (input.id === 'mast-s' && !box.contains(e.target) && e.target !== input) box.hidden = true; });
    });
  }

  // Tablas que se deslizan en el móvil: se pueden recorrer con el teclado y se anuncian con su título
  function initTables() {
    $$('.jm-table-wrap').forEach(function (w) {
      if (w.hasAttribute('tabindex')) return;
      w.setAttribute('tabindex', '0');
      if (!w.hasAttribute('role')) w.setAttribute('role', 'region');
      if (!w.hasAttribute('aria-label') && !w.hasAttribute('aria-labelledby')) {
        var c = $('caption', w); w.setAttribute('aria-label', c ? c.textContent.trim() : 'Tabla');
      }
    });
  }

  // Portada: «Explora las guías». Los temas pasan a ser pestañas (sin JavaScript son enlaces a cada tema):
  // con clic, flechas del teclado o deslizando el dedo sobre la lista. Un resalte se desliza bajo el ratón
  // de una guía a otra y las fotos de cada tema se piden al abrirlo (o al acercar el ratón a su icono).
  function initBrowse() {
    var root = $('.jm-browse'); if (!root) return;
    var nav = $('.jm-browse__nav', root), strip = $('.jm-browse__strip', root), bar = $('.jm-browse__bar', root);
    var tabs = $$('.jm-browse__tab', root), panes = tabs.map(function (t) { return document.getElementById(t.getAttribute('data-pane')); });
    if (!tabs.length || panes.indexOf(null) >= 0) return;
    var cur = Math.max(0, tabs.findIndex(function (t) { return t.classList.contains('is-on'); })), timer = 0;
    strip.setAttribute('role', 'tablist');
    tabs.forEach(function (t, i) {
      t.setAttribute('role', 'tab');
      t.removeAttribute('aria-current');
      t.setAttribute('aria-controls', panes[i].id);
      t.setAttribute('aria-selected', i === cur ? 'true' : 'false');
      t.setAttribute('tabindex', i === cur ? '0' : '-1');
      panes[i].setAttribute('role', 'tabpanel');
      panes[i].setAttribute('aria-labelledby', t.id);
    });
    root.classList.add('is-live');

    function photos(pane) {
      $$('.jm-browse__thumb[data-img]', pane).forEach(function (th) {
        var img = new Image(); img.alt = ''; img.width = 52; img.height = 52; img.decoding = 'async';
        img.className = 'is-new'; img.src = th.getAttribute('data-img');
        th.removeAttribute('data-img'); th.appendChild(img);
      });
    }
    function placeBar() {
      var t = tabs[cur]; if (!bar || !t) return;
      bar.style.setProperty('--bx', (t.offsetLeft + t.offsetWidth / 2 - 11).toFixed(1) + 'px');
    }
    function edges() {
      var max = strip.scrollWidth - strip.clientWidth;
      nav.classList.toggle('can-prev', strip.scrollLeft > 4);
      nav.classList.toggle('can-next', strip.scrollLeft < max - 4);
    }
    // Lleva el tema elegido a la vista dentro de su fila (sin mover la página)
    function reveal(t) {
      var l = t.offsetLeft, r = l + t.offsetWidth, pad = 48, to = strip.scrollLeft;
      if (l - pad < strip.scrollLeft) to = l - pad; else if (r + pad > strip.scrollLeft + strip.clientWidth) to = r + pad - strip.clientWidth;
      if (to !== strip.scrollLeft) strip.scrollTo({ left: Math.max(0, to), behavior: calm ? 'auto' : 'smooth' });
    }
    function select(i, focus) {
      if (i < 0 || i >= tabs.length) return;
      if (focus) tabs[i].focus({ preventScroll: true });
      reveal(tabs[i]);
      if (i === cur) return;
      var prev = cur, dir = i > prev ? 1 : -1; cur = i;
      tabs.forEach(function (t, k) {
        var on = k === i;
        t.classList.toggle('is-on', on); t.setAttribute('aria-selected', on ? 'true' : 'false'); t.setAttribute('tabindex', on ? '0' : '-1');
      });
      photos(panes[i]);
      root.style.setProperty('--dir', dir);
      panes.forEach(function (p) { p.classList.remove('is-in', 'is-out'); });
      panes[prev].classList.remove('is-on');
      panes[i].classList.add('is-on');
      if (!calm) {
        panes[prev].classList.add('is-out'); panes[i].classList.add('is-in');
        tabs[i].classList.remove('is-pop'); void tabs[i].offsetWidth; tabs[i].classList.add('is-pop');
        clearTimeout(timer);
        timer = setTimeout(function () { panes.forEach(function (p) { p.classList.remove('is-in', 'is-out'); }); tabs[i].classList.remove('is-pop'); }, 1000);
      }
      placeBar();
    }
    tabs.forEach(function (t, i) {
      t.addEventListener('click', function (e) {
        if (e.button || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return; // abrir el tema en otra pestaña sigue funcionando
        e.preventDefault(); select(i, false);
      });
      t.addEventListener('pointerenter', function () { photos(panes[i]); });
      t.addEventListener('focus', function () { photos(panes[i]); });
    });
    strip.addEventListener('keydown', function (e) {
      var k = e.key, n = tabs.length, to = -1;
      if (k === 'ArrowRight') to = (cur + 1) % n;
      else if (k === 'ArrowLeft') to = (cur - 1 + n) % n;
      else if (k === 'Home') to = 0;
      else if (k === 'End') to = n - 1;
      else if (k === ' ' || k === 'Enter') { e.preventDefault(); return; } // el tema enfocado ya está elegido
      if (to < 0) return;
      e.preventDefault(); select(to, true);
    });

    // Flechas de la fila de temas y sombras en los bordes cuando hay más temas a un lado
    $$('.jm-browse__paddle', root).forEach(function (b) {
      b.addEventListener('click', function () {
        var d = b.classList.contains('jm-browse__paddle--prev') ? -1 : 1;
        strip.scrollBy({ left: d * strip.clientWidth * 0.7, behavior: calm ? 'auto' : 'smooth' });
      });
    });
    strip.addEventListener('scroll', function () { if (!edges.raf) edges.raf = requestAnimationFrame(function () { edges.raf = 0; edges(); }); }, { passive: true });
    if ('ResizeObserver' in window) new ResizeObserver(function () { edges(); placeBar(); }).observe(strip); else window.addEventListener('resize', function () { edges(); placeBar(); });
    edges(); placeBar();
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () { edges(); placeBar(); });

    // Resalte que se desliza bajo el ratón de una guía a otra
    if (fine) {
      panes.forEach(function (p) {
        var list = $('.jm-browse__list', p); if (!list) return;
        var lens = document.createElement('i'); lens.className = 'jm-browse__lens'; lens.setAttribute('aria-hidden', 'true');
        list.insertBefore(lens, list.firstChild);
        list.addEventListener('pointerover', function (e) {
          if (e.pointerType && e.pointerType !== 'mouse') return;
          var row = e.target.closest ? e.target.closest('.jm-browse__row') : null; if (!row) return;
          var first = !list.classList.contains('is-hover');
          if (first) lens.style.transition = 'none';
          lens.style.setProperty('--ly', row.offsetTop + 'px'); lens.style.height = row.offsetHeight + 'px';
          if (first) { void lens.offsetWidth; lens.style.transition = ''; }
          list.classList.add('is-hover');
        });
        list.addEventListener('pointerleave', function () { list.classList.remove('is-hover'); });
      });
    }

    // Con el dedo: deslizar la lista a un lado cambia de tema
    var box = $('.jm-browse__panes', root), sx = 0, sy = 0, live = false, swiped = 0;
    box.style.touchAction = 'pan-y';
    box.addEventListener('pointerdown', function (e) { if (e.pointerType !== 'touch') return; sx = e.clientX; sy = e.clientY; live = true; }, { passive: true });
    box.addEventListener('pointerup', function (e) {
      if (!live) return; live = false;
      var dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) > 56 && Math.abs(dx) > Math.abs(dy) * 1.6) { swiped = Date.now(); select(cur + (dx < 0 ? 1 : -1), false); }
    });
    box.addEventListener('pointercancel', function () { live = false; });
    box.addEventListener('click', function (e) { if (Date.now() - swiped < 450) { e.preventDefault(); e.stopPropagation(); } }, true);
  }

  // El grabado es solo adorno y crear el lienzo cuesta: se dibuja cuando el navegador ya ha pintado el texto
  function later(fn) { return function () { if ('requestIdleCallback' in window) requestIdleCallback(function () { safe(fn); }, { timeout: 1500 }); else setTimeout(function () { safe(fn); }, 300); }; }
  function init() { [initResume, initTables, initHeader, initDrawer, initSearch, initForms, initCookies, initDatos, initToc, initProgress, initShare, initNativeShare, initCopyCode, initStats, initAnalytics, initReveal, initRoll, initTilt, initStage, initBrowse, later(initGuilloche), initDevelop, initPress, initMorph, initFontSize, initListen, initPrint, initLiveSearch, initGuideFilter, initTimelineMore].forEach(safe); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
