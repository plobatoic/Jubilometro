<?php
/**
 * Jubilómetro · tema hijo de Kadence.
 * Portada tipo revista, plantilla de artículo, listados por tema y rendimiento.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'JM_THEME', true );
define( 'JM_THEME_VER', '2.11.45' );
define( 'JM_THEME_DIR', get_stylesheet_directory() );
define( 'JM_THEME_URI', get_stylesheet_directory_uri() );

require_once JM_THEME_DIR . '/inc/historias.php';
require_once JM_THEME_DIR . '/inc/estadisticas.php';
require_once JM_THEME_DIR . '/inc/difusion.php';

// Montaje pendiente (páginas e imágenes): se ejecuta aunque su plugin esté desactivado, hasta completarse
const JM_SETUP_TARGET = '1.3.6';
add_action( 'after_setup_theme', function () {
	$f = WP_PLUGIN_DIR . '/jubilometro-setup/jubilometro-setup.php';
	if ( ! function_exists( 'jm_setup_run' ) && get_option( 'jm_setup_version' ) !== JM_SETUP_TARGET && file_exists( $f ) ) {
		require_once $f;
	}
} );

/* ------------------------------------------------------------------
 * 1. SOPORTE DEL TEMA
 * ------------------------------------------------------------------ */
add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'automatic-feed-links' ); // RSS de las guías: lectores de noticias y descubrimiento de novedades
	set_post_thumbnail_size( 1600, 1067 );
}, 20 );

/* ------------------------------------------------------------------
 * 2. ESTILOS Y SCRIPTS: solo los del diseño (sin CSS de Kadence ni Google Fonts)
 * ------------------------------------------------------------------ */
add_action( 'wp_enqueue_scripts', function () {
	foreach ( array( wp_styles(), wp_scripts() ) as $reg ) {
		foreach ( (array) $reg->queue as $h ) {
			$src = isset( $reg->registered[ $h ] ) ? (string) $reg->registered[ $h ]->src : '';
			// Fuera: CSS de Kadence, Google Fonts y el script de Hostinger Reach (la web no lo usa y carga un tercero en cada visita)
			if ( false !== strpos( $src, '/themes/kadence/' ) || false !== strpos( $src, 'fonts.googleapis.com' ) || false !== strpos( $h, 'hostinger-reach' ) || false !== strpos( $src, 'reach.hostinger.com' ) ) {
				$reg instanceof WP_Styles ? wp_dequeue_style( $h ) : wp_dequeue_script( $h );
			}
		}
	}
	wp_enqueue_style( 'jubilometro', JM_THEME_URI . '/assets/css/jubilometro.css', array(), JM_THEME_VER );
	wp_enqueue_script( 'jm-site', JM_THEME_URI . '/assets/js/jubilometro.js', array(), JM_THEME_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	$post    = get_post();
	$content = ( $post && is_singular() ) ? $post->post_content : '';
	if ( is_front_page() || false !== strpos( $content, 'data-jm-calc' ) || false !== strpos( $content, 'data-jm-sim' ) ) {
		wp_enqueue_script( 'jm-calculadoras', JM_THEME_URI . '/assets/js/calculadoras.js', array(), JM_THEME_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}
	// Simulador animado: su hoja y su script solo en su página
	if ( false !== strpos( $content, 'data-jm-sim' ) ) {
		wp_enqueue_style( 'jm-simulador', JM_THEME_URI . '/assets/css/simulador.css', array( 'jubilometro' ), JM_THEME_VER );
		wp_enqueue_script( 'jm-simulador', JM_THEME_URI . '/assets/js/simulador.js', array( 'jm-calculadoras' ), JM_THEME_VER, array( 'strategy' => 'defer', 'in_footer' => true ) );
	}
}, 100 );

add_action( 'wp_head', function () {
	// Tamaño de letra elegido por el lector: se aplica antes de pintar (sin salto de página)
	echo "<script>try{var f=localStorage.getItem('jm_fs');if(f)document.documentElement.setAttribute('data-jm-fs',f)}catch(e){}</script>\n";
	// Solo la fuente del texto; la mono (fechas y cifras) llega sin bloquear
	// Las dos letras del diseño (titulares y texto): se piden en paralelo con la hoja de estilos
	foreach ( array( 'newsreader-normal-latin', 'public-sans-normal-latin' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( JM_THEME_URI . '/assets/fonts/' . $f . '.woff2' ) );
	}
	echo '<meta name="theme-color" content="#FFFFFF">' . "\n";
	printf( '<link rel="manifest" href="%s">' . "\n", esc_url( JM_THEME_URI . '/manifest.json' ) );
}, 2 );

// Icono vectorial (nítido en cualquier tamaño) además del icono del sitio que genera WordPress
add_action( 'wp_head', function () {
	echo '<link rel="icon" href="' . esc_url( JM_THEME_URI . '/assets/img/favicon.svg' ) . '" type="image/svg+xml" sizes="any">' . "\n";
}, 100 );

// Diseño nuevo publicado: se vacía la caché de LiteSpeed para que nadie reciba páginas con el diseño anterior
add_action( 'init', function () {
	if ( get_option( 'jm_theme_ver' ) === JM_THEME_VER ) { return; }
	update_option( 'jm_theme_ver', JM_THEME_VER, false );
	do_action( 'litespeed_purge_all' );
} );

// Tamaños de foto: se usan los que marca el diseño para cada hueco (sin el "sizes=auto" de WordPress,
// que en móvil hacía descargar versiones de 768 px para miniaturas de 100 px)
add_filter( 'wp_img_tag_add_auto_sizes', '__return_false' );
// Los comentarios están cerrados: sin enlace al feed de comentarios
add_filter( 'feed_links_show_comments_feed', '__return_false' );

// Navegación instantánea: el navegador precarga la guía al dejar el ratón encima (reglas de especulación de WordPress)
add_filter( 'wp_speculation_rules_configuration', function ( $config ) {
	if ( is_array( $config ) ) { $config['eagerness'] = 'moderate'; }
	return $config;
} );

// Cabeceras de seguridad (no afectan al diseño; suman confianza para navegadores y buscadores)
add_action( 'send_headers', function () {
	if ( is_admin() ) { return; }
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Referrer-Policy: strict-origin-when-cross-origin' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Permissions-Policy: camera=(), microphone=(), geolocation=()' );
	if ( is_ssl() ) { header( 'Strict-Transport-Security: max-age=31536000' ); }
} );

// El tema padre (Kadence) pinta al final un script que mide la ventana y obliga al navegador a maquetar
// toda la página otra vez (≈0,6 s en móvil). Este diseño no lo usa: se retira del pie.
add_action( 'wp_footer', function () { ob_start(); }, -1000 );
add_action( 'wp_footer', function () {
	$html = (string) ob_get_clean();
	echo preg_replace( '#<script>\s*document\.documentElement\.style\.setProperty\(\s*[\'"]--scrollbar-offset[\'"].*?</script>\s*#s', '', $html ); // phpcs:ignore
}, PHP_INT_MAX );

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
// XML-RPC (publicar desde aplicaciones antiguas) no se usa: se cierra, que es un blanco habitual de ataques
add_filter( 'xmlrpc_enabled', '__return_false' );
add_filter( 'wp_headers', function ( $h ) { unset( $h['X-Pingback'] ); return $h; } );
remove_action( 'wp_head', 'rsd_link' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
// Sin avisos de conexión a servicios que la web no usa
add_filter( 'wp_resource_hints', function ( $urls ) {
	return array_values( array_filter( (array) $urls, function ( $u ) {
		$h = is_array( $u ) ? ( $u['href'] ?? '' ) : (string) $u;
		return false === strpos( $h, 'reach.hostinger.com' );
	} ) );
}, 99 );
// La API no publica la lista de usuarios a quien no ha iniciado sesión: así no se puede
// averiguar el nombre de acceso de la cuenta (la firma de autor sigue en cada artículo).
add_filter( 'rest_endpoints', function ( $endpoints ) {
	if ( is_user_logged_in() ) { return $endpoints; }
	unset( $endpoints['/wp/v2/users'], $endpoints['/wp/v2/users/(?P<id>[\d]+)'] );
	return $endpoints;
} );

/*
 * Actualizar este tema por la API: POST /wp-json/jm-tema/v1/instalar con el zip en el campo «tema»
 * (multipart). Es lo mismo que Apariencia > Temas > Subir tema > «Reemplazar el instalado con el
 * subido», con los mismos permisos (solo un administrador autenticado, p. ej. con contraseña de
 * aplicación), y solo acepta un zip del propio tema Jubilómetro.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'jm-tema/v1', '/instalar', array(
		'methods'             => 'POST',
		'permission_callback' => function () { return current_user_can( 'install_themes' ) && current_user_can( 'update_themes' ); },
		'callback'            => 'jm_tema_instalar',
	) );
} );
function jm_tema_instalar( WP_REST_Request $req ) {
	$f = $req->get_file_params();
	if ( empty( $f['tema']['tmp_name'] ) || ! is_uploaded_file( $f['tema']['tmp_name'] ) ) {
		return new WP_Error( 'jm_sin_zip', 'Falta el zip del tema en el campo «tema».', array( 'status' => 400 ) );
	}
	if ( ! class_exists( 'ZipArchive' ) ) {
		return new WP_Error( 'jm_sin_zip', 'El servidor no puede abrir archivos zip.', array( 'status' => 500 ) );
	}
	$zip = new ZipArchive();
	if ( true !== $zip->open( $f['tema']['tmp_name'] ) ) {
		return new WP_Error( 'jm_zip_malo', 'El archivo no es un zip válido.', array( 'status' => 400 ) );
	}
	$css = $zip->getFromName( 'jubilometro/style.css' );
	$raiz = true;
	for ( $i = 0; $i < $zip->numFiles; $i++ ) {
		if ( 0 !== strpos( (string) $zip->getNameIndex( $i ), 'jubilometro/' ) ) { $raiz = false; break; }
	}
	$zip->close();
	if ( ! $raiz || ! $css || ! preg_match( '/^\s*Theme Name:\s*Jubilómetro\s*$/mu', $css ) || ! preg_match( '/^\s*Version:\s*([\w.-]+)/m', $css, $v ) ) {
		return new WP_Error( 'jm_otro_tema', 'El zip no es el tema Jubilómetro (carpeta jubilometro/ con su style.css).', array( 'status' => 400 ) );
	}
	$paquete = wp_tempnam( 'jubilometro-tema.zip' );
	if ( ! $paquete || ! move_uploaded_file( $f['tema']['tmp_name'], $paquete ) ) {
		return new WP_Error( 'jm_copia', 'No se pudo guardar el zip en el servidor.', array( 'status' => 500 ) );
	}
	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/misc.php';
	require_once ABSPATH . 'wp-admin/includes/theme.php';
	require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
	$skin = new WP_Ajax_Upgrader_Skin();
	$res  = ( new Theme_Upgrader( $skin ) )->install( $paquete, array( 'overwrite_package' => true, 'clear_update_cache' => true ) );
	wp_delete_file( $paquete );
	if ( is_wp_error( $res ) ) { return $res; }
	if ( ! $res ) {
		return new WP_Error( 'jm_fallo', implode( ' ', (array) $skin->get_error_messages() ) ?: 'La instalación no se completó.', array( 'status' => 500 ) );
	}
	do_action( 'litespeed_purge_all' );
	return array( 'instalado' => true, 'version' => $v[1] );
}

/* ------------------------------------------------------------------
 * 3. CLASES DEL BODY
 *    jm-live: oculta al público las zonas de redacción (solo las ve el editor conectado)
 *    jm-ads-on: muestra los huecos de anuncio cuando AdSense está configurado
 *    jm-cmp: muestra «Configurar cookies» cuando hay ID de AdSense (y con él, el aviso de Google)
 * ------------------------------------------------------------------ */
add_filter( 'body_class', function ( $c ) {
	$c[] = 'jm-live';
	if ( defined( 'JM_ADSENSE' ) && JM_ADSENSE ) { $c[] = 'jm-ads-on'; }
	if ( '' !== jm_adsense_client() ) { $c[] = 'jm-cmp'; }
	return $c;
} );

/* ------------------------------------------------------------------
 * 4. PIEZAS DEL DISEÑO (HTML generado junto al prototipo)
 * ------------------------------------------------------------------ */
function jm_part( $name ) {
	$f = JM_THEME_DIR . '/parts/' . $name . '.html';
	if ( ! file_exists( $f ) ) { return ''; }
	$html = (string) file_get_contents( $f ); // phpcs:ignore
	return jm_local_imgs( jm_fix_links( do_shortcode( jm_rev_dates( $html ) ) ) );
}

/*
 * Fotos de Unsplash de las páginas y de la portada: en cuanto el montaje las ha traído a la biblioteca
 * de medios, se sirven desde la propia web (más rápido, sin enviar la IP del lector a un tercero
 * y con valor para Google Imágenes). Si aún no están, se deja la original.
 */
function jm_local_imgs( $html ) {
	if ( false === strpos( $html, 'images.unsplash.com/photo-' ) ) { return $html; }
	$map = get_option( 'jm_unsplash_map', array() );
	if ( ! $map || ! is_array( $map ) ) { return $html; }
	return preg_replace_callback( '#<img\b[^>]*>#', function ( $m ) use ( $map ) {
		$tag = $m[0];
		if ( ! preg_match( '#images\.unsplash\.com/photo-([A-Za-z0-9-]+)\?#', $tag, $x ) || empty( $map[ $x[1] ] ) ) { return $tag; }
		$aid = (int) $map[ $x[1] ];
		$src = wp_get_attachment_image_url( $aid, 'large' );
		if ( ! $src ) { return $tag; }
		$set = wp_get_attachment_image_srcset( $aid, 'large' );
		$tag = preg_replace( '#\ssrcset="[^"]*"#', '', $tag );
		$tag = preg_replace( '#\ssrc="[^"]*"#', ' src="' . esc_url( $src ) . '"' . ( $set ? ' srcset="' . esc_attr( $set ) . '"' : '' ), $tag );
		return str_replace( '<img', '<img data-jm-local', $tag );
	}, $html );
}
add_filter( 'the_content', 'jm_local_imgs', 27 );

// Fechas de revisión (<span data-jm-rev>): la de la última guía publicada o actualizada;
// dentro de una guía, la de esa guía.
function jm_rev_dates( $html ) {
	if ( false === strpos( $html, 'data-jm-rev' ) ) { return $html; }
	$last = is_singular( 'post' ) ? get_post_field( 'post_modified', get_queried_object_id() ) : get_lastpostmodified( 'blog', 'post' );
	if ( ! $last ) { return $html; }
	$t    = strtotime( $last );
	$html = preg_replace( '/(<span data-jm-rev="short">)[^<]*/', '${1}' . date_i18n( 'd·m·y', $t ), $html );
	return preg_replace( '/(<span data-jm-rev="long">)[^<]*/', '${1}' . date_i18n( 'j \d\e F \d\e Y', $t ), $html );
}
// En las guías, la fecha es la de la propia guía. En las páginas (temas, calculadoras) se deja la fecha
// en que se verificaron sus cifras, que es la que coincide con su recuadro «Revisado por».
add_filter( 'the_content', function ( $html ) { return is_singular( 'post' ) ? jm_rev_dates( $html ) : $html; }, 26 );

// Índice para el buscador instantáneo: guías publicadas, calculadoras y temas (≈10 KB, en caché 12 h)
function jm_indice() {
	$data = get_transient( 'jm_indice_v1' );
	if ( is_array( $data ) ) { return $data; }
	$data = array();
	foreach ( get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => 500, 'no_found_rows' => true ) ) as $p ) {
		$c      = jm_primary_cat( $p->ID );
		$data[] = array(
			't' => html_entity_decode( get_the_title( $p ), ENT_QUOTES, 'UTF-8' ),
			'u' => wp_make_link_relative( get_permalink( $p ) ),
			'c' => $c ? $c->name : 'Guía',
			'n' => jm_num( $p ),
			'k' => 'guia',
			'e' => html_entity_decode( wp_trim_words( get_the_excerpt( $p ), 24, '…' ), ENT_QUOTES, 'UTF-8' ),
		);
	}
	foreach ( (array) jm_data( 'calcs' ) as $cc ) {
		if ( empty( $cc['slug'] ) ) { continue; }
		$data[] = array( 't' => $cc['name'] ?? $cc['short'], 'u' => '/calculadoras/' . $cc['slug'] . '/', 'c' => 'Calculadora', 'n' => '', 'k' => 'calc', 'e' => $cc['desc'] ?? '' );
	}
	$cats = jm_data( 'cats' );
	foreach ( (array) jm_data( 'temas' ) as $slug ) {
		$term = get_category_by_slug( $slug );
		if ( $term ) { $data[] = array( 't' => $term->name, 'u' => '/' . $slug . '/', 'c' => 'Tema', 'n' => '', 'k' => 'tema', 'e' => $cats[ $slug ]['desc'] ?? '' ); }
	}
	set_transient( 'jm_indice_v1', $data, 12 * HOUR_IN_SECONDS );
	return $data;
}
add_action( 'rest_api_init', function () {
	register_rest_route( 'jm/v1', '/indice', array(
		'methods'             => 'GET',
		'permission_callback' => '__return_true',
		'callback'            => function () {
			$r = rest_ensure_response( jm_indice() );
			$r->header( 'Cache-Control', 'public, max-age=3600' );
			$r->header( 'X-Robots-Tag', 'noindex' );
			return $r;
		},
	) );
} );
add_action( 'save_post', function () { delete_transient( 'jm_indice_v1' ); } );
add_action( 'deleted_post', function () { delete_transient( 'jm_indice_v1' ); } );

// [jm_cuenta cat="viudedad"]: guías publicadas de un tema, en palabras
add_shortcode( 'jm_cuenta', function ( $a ) {
	$a    = shortcode_atts( array( 'cat' => '' ), $a );
	$term = $a['cat'] ? get_category_by_slug( $a['cat'] ) : null;
	$n    = $term ? (int) $term->count : 0;
	return $n ? esc_html( sprintf( _n( '%d guía publicada', '%d guías publicadas', $n, 'jubilometro' ), $n ) ) : 'Guías en preparación';
} );

/*
 * Enlaces internos a guías que aún no están publicadas: en lugar de dejar que Google encuentre
 * una redirección, el enlace apunta directamente a la guía (si se publicó con otro nombre) o a la página del tema.
 */
function jm_fix_links( $html ) {
	static $pub = null, $old = array();
	if ( false === strpos( $html, 'href=' ) ) { return $html; }
	if ( null === $pub ) {
		$pub = array();
		$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true ) );
		foreach ( $ids as $id ) { $pub[ untrailingslashit( wp_make_link_relative( get_permalink( $id ) ) ) ] = true; }
	}
	$temas = jm_data( 'temas' );
	$host  = preg_quote( (string) wp_parse_url( home_url(), PHP_URL_HOST ), '#' );
	return preg_replace_callback( '#href="(?:https?://(?:www\.)?' . $host . ')?/([a-z0-9-]+)/([a-z0-9-]+)/"#', function ( $m ) use ( $pub, $temas, &$old ) {
		if ( ! in_array( $m[1], $temas, true ) || isset( $pub[ '/' . $m[1] . '/' . $m[2] ] ) ) { return $m[0]; }
		if ( ! array_key_exists( $m[2], $old ) ) {
			$r = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'meta_key' => '_wp_old_slug', 'meta_value' => $m[2], 'posts_per_page' => 1, 'fields' => 'ids', 'no_found_rows' => true ) ); // phpcs:ignore
			$old[ $m[2] ] = $r ? get_permalink( $r[0] ) : '';
		}
		return 'href="' . esc_url( $old[ $m[2] ] ? $old[ $m[2] ] : home_url( '/' . $m[1] . '/' ) ) . '"';
	}, $html );
}
add_filter( 'the_content', 'jm_fix_links', 30 );

// Cifra clave de cada guía (aparece en la libreta de la portada). Editable en la guía y por la API.
add_action( 'init', function () {
	register_post_meta( 'post', '_jm_cifra', array(
		'type'          => 'string',
		'single'        => true,
		'show_in_rest'  => true,
		'auth_callback' => function ( $allowed, $key, $post_id ) { return current_user_can( 'edit_post', $post_id ); },
		'sanitize_callback' => function ( $v ) { return mb_substr( sanitize_text_field( $v ), 0, 14 ); },
	) );
} );
add_action( 'add_meta_boxes_post', function () {
	add_meta_box( 'jm-cifra', 'Cifra clave (libreta de la portada)', function ( $post ) {
		wp_nonce_field( 'jm_cifra', 'jm_cifra_nonce' );
		printf(
			'<p><input type="text" name="jm_cifra" value="%s" maxlength="14" style="width:100%%" placeholder="Ej.: 35 años"></p><p class="description">El dato principal de la guía, en pocas letras (35 años, 3.359,60 €, +2,7 %%). Déjalo vacío si no hay una cifra clara: se mostrarán los minutos de lectura.</p>',
			esc_attr( (string) get_post_meta( $post->ID, '_jm_cifra', true ) )
		);
	}, 'post', 'side', 'default' );
} );
add_action( 'save_post_post', function ( $post_id ) {
	if ( ! isset( $_POST['jm_cifra_nonce'] ) || ! wp_verify_nonce( sanitize_key( $_POST['jm_cifra_nonce'] ), 'jm_cifra' ) ) { return; }
	if ( ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) || ! current_user_can( 'edit_post', $post_id ) ) { return; }
	$v = isset( $_POST['jm_cifra'] ) ? mb_substr( sanitize_text_field( wp_unslash( $_POST['jm_cifra'] ) ), 0, 14 ) : '';
	'' === $v ? delete_post_meta( $post_id, '_jm_cifra' ) : update_post_meta( $post_id, '_jm_cifra', $v );
} );

// Sección actual (para marcar el menú)
function jm_section() {
	if ( is_front_page() ) { return 'home'; }
	if ( is_singular( 'post' ) ) {
		$c = jm_primary_cat( get_queried_object_id() );
		return $c ? $c->slug : '';
	}
	if ( is_page() ) {
		$id  = get_queried_object_id();
		$anc = get_post_ancestors( $id );
		$top = $anc ? end( $anc ) : $id;
		return get_post_field( 'post_name', $top );
	}
	return '';
}

function jm_header_html() {
	$html = jm_part( 'header' );
	$sec  = jm_section();
	if ( $sec ) {
		$html = str_replace( 'data-k="' . $sec . '"', 'data-k="' . $sec . '" aria-current="page"', $html );
		if ( in_array( $sec, array( 'guias', 'incapacidad', 'ayudas', 'dinero' ), true ) ) {
			$html = preg_replace( '/<button type="button" aria-haspopup="true">/', '<button type="button" aria-haspopup="true" aria-current="true">', $html, 1 );
		}
	}
	return $html;
}

/* ------------------------------------------------------------------
 * 5. ARTÍCULOS: índice automático, "Revisado por" en la cabecera y lecturas
 * ------------------------------------------------------------------ */
// Devuelve [contenido con anclas, lista de H2]
function jm_toc( $html ) {
	$toc  = array();
	$seen = array();
	$html = preg_replace_callback( '#<h2(\s[^>]*)?>(.*?)</h2>#is', function ( $m ) use ( &$toc, &$seen ) {
		$attrs = isset( $m[1] ) ? $m[1] : '';
		if ( preg_match( '/class="[^"]*jm-/', $attrs ) ) { return $m[0]; }
		$text = trim( wp_strip_all_tags( $m[2] ) );
		if ( '' === $text || 0 === strpos( $text, 'Datos clave' ) ) { return $m[0]; }
		if ( preg_match( '/\sid="([^"]+)"/', $attrs, $idm ) ) {
			$id = $idm[1];
		} else {
			$id = sanitize_title( $text );
			$base = $id; $i = 2;
			while ( isset( $seen[ $id ] ) ) { $id = $base . '-' . $i++; }
			$attrs .= ' id="' . esc_attr( $id ) . '"';
		}
		$seen[ $id ] = true;
		$toc[]       = array( $id, $text );
		return '<h2' . $attrs . '>' . $m[2] . '</h2>';
	}, $html );
	return array( $html, $toc );
}

function jm_toc_list( $toc ) {
	$o = '<ol>';
	foreach ( $toc as $t ) { $o .= '<li><a href="#' . esc_attr( $t[0] ) . '">' . esc_html( $t[1] ) . '</a></li>'; }
	return $o . '</ol>';
}

// En la entrada, el "Revisado por" va en la cabecera: se quita el bloque repetido del contenido
function jm_strip_reviewed( $html ) {
	return preg_replace( '#<div class="jm-reviewed">.*?</p>\s*</div>#s', '', $html, 1 );
}

// Lecturas del mes (para "Lo más leído"): señal ligera desde el navegador, sin cookies
function jm_views_key() { return 'jm_views_' . gmdate( 'Ym' ); }
add_action( 'wp_ajax_jm_view', 'jm_count_view' );
add_action( 'wp_ajax_nopriv_jm_view', 'jm_count_view' );
function jm_count_view() {
	$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0; // phpcs:ignore
	if ( $id && 'post' === get_post_type( $id ) && 'publish' === get_post_status( $id ) && ! current_user_can( 'edit_posts' ) ) {
		$k = jm_views_key();
		update_post_meta( $id, $k, (int) get_post_meta( $id, $k, true ) + 1 );
	}
	wp_die( '', '', array( 'response' => 204 ) );
}

// Número de apunte (Guía nº 063…): cada guía nueva recibe el siguiente al publicarse
function jm_assign_num( $post_id ) {
	if ( 'post' !== get_post_type( $post_id ) || get_post_meta( $post_id, '_jm_num', true ) ) { return; }
	global $wpdb;
	$max = (int) $wpdb->get_var( "SELECT MAX(CAST(meta_value AS UNSIGNED)) FROM {$wpdb->postmeta} WHERE meta_key = '_jm_num'" );
	update_post_meta( $post_id, '_jm_num', $max + 1 );
}
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'publish' === $new && 'post' === $post->post_type ) { jm_assign_num( $post->ID ); }
}, 10, 3 );
add_action( 'init', function () {
	if ( get_option( 'jm_nums_v1' ) ) { return; }
	update_option( 'jm_nums_v1', 1, false );
	$ids = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'ASC', 'fields' => 'ids', 'meta_query' => array( array( 'key' => '_jm_num', 'compare' => 'NOT EXISTS' ) ) ) ); // phpcs:ignore
	foreach ( $ids as $id ) { jm_assign_num( $id ); }
}, 30 );

// Buscador: sin la portada ni las páginas legales entre los resultados
add_action( 'pre_get_posts', function ( $q ) {
	if ( is_admin() || ! $q->is_main_query() || ! $q->is_search() ) { return; }
	$ex = array( (int) get_option( 'page_on_front' ) );
	foreach ( array( 'aviso-legal', 'politica-privacidad', 'politica-cookies', 'descargo-responsabilidad', 'accesibilidad', 'contacto' ) as $s ) {
		$p = get_page_by_path( $s );
		if ( $p ) { $ex[] = (int) $p->ID; }
	}
	$q->set( 'post__not_in', $ex );
} );

/* ------------------------------------------------------------------
 * 6. URLS QUE NO EXISTEN: error 404 limpio (sin redirecciones que Google trate como "soft 404").
 *    Los enlaces internos a guías sin publicar ya se corrigen en jm_fix_links().
 *    Las páginas no tienen paginación: /jubilacion/page/2/ también es 404.
 * ------------------------------------------------------------------ */
add_action( 'template_redirect', function () {
	// También la portada: /page/2/ repetía la portada (con noindex) y gastaba rastreo de Google
	if ( ( is_page() || is_front_page() || is_home() ) && max( (int) get_query_var( 'paged' ), (int) get_query_var( 'page' ) ) > 1 ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}, 1 );

/* ------------------------------------------------------------------
 * 7. VISTA PREVIA DE BORRADORES PARA REVISIÓN (clave temporal, sin sesión)
 *    Solo funciona mientras exista la opción jm_qa_key; se borra al terminar la revisión.
 * ------------------------------------------------------------------ */
function jm_qa_ok() {
	static $ok = null;
	if ( null === $ok ) {
		$key = get_option( 'jm_qa_key' );
		$ok  = $key && ! empty( $_GET['jm_qa'] ) && hash_equals( (string) $key, (string) wp_unslash( $_GET['jm_qa'] ) ); // phpcs:ignore
	}
	return $ok;
}
add_filter( 'posts_results', function ( $posts, $q ) {
	if ( is_admin() || ! $q->is_main_query() || ! jm_qa_ok() ) { return $posts; }
	foreach ( $posts as $p ) {
		if ( 'draft' === $p->post_status ) { $p->post_status = 'publish'; }
	}
	return $posts;
}, 10, 2 );
add_action( 'template_redirect', function () {
	if ( jm_qa_ok() ) {
		if ( ! defined( 'DONOTCACHEPAGE' ) ) { define( 'DONOTCACHEPAGE', true ); }
		do_action( 'litespeed_control_set_nocache', 'revision jm' );
		header( 'X-Robots-Tag: noindex, nofollow' );
	}
}, 1 );
add_filter( 'redirect_canonical', function ( $r ) { return jm_qa_ok() ? false : $r; } );

/* ------------------------------------------------------------------
 * 8. LISTADOS EN PÁGINAS: [jm_articulos cat="viudedad"] y [jm_guias]
 * ------------------------------------------------------------------ */
// Guías previstas (borradores) de un tema: solo se cuentan, nunca se enseñan como fichas
function jm_prep_count( $cat ) {
	return (int) ( new WP_Query( array( 'post_type' => 'post', 'post_status' => 'draft', 'category_name' => $cat, 'fields' => 'ids', 'posts_per_page' => -1, 'no_found_rows' => true ) ) )->post_count;
}
function jm_prep_note( $n, $cat = '' ) {
	// Desde la 2.1 no se anuncian guías en preparación: para los lectores y para AdSense, el sitio
	// no debe parecer en obras. Los borradores siguen ahí y salen solos al publicarse.
	if ( $n < 1 || ! apply_filters( 'jm_show_prep_note', false ) ) { return ''; }
	$txt = sprintf( _n( 'Estamos preparando %d guía más sobre este tema.', 'Estamos preparando %d guías más sobre este tema.', $n, 'jubilometro' ), $n );
	return '<p class="jm-prep">' . jm_icon( 'refresh' ) . '<span>' . esc_html( $txt ) . ' <a href="' . esc_url( home_url( '/#newsletter' ) ) . '">Te avisamos por correo cuando salgan</a>.</span></p>';
}

add_shortcode( 'jm_articulos', function ( $a ) {
	$a    = shortcode_atts( array( 'cat' => '', 'n' => 24 ), $a );
	$list = jm_stories( $a['cat'], (int) $a['n'], array(), false, false );
	$note = $a['cat'] ? jm_prep_note( jm_prep_count( $a['cat'] ) ) : '';
	if ( ! $list ) { return $note; }
	$cols = 0 === count( $list ) % 4 ? ' jm-silo--4' : '';
	$o    = '<div class="jm-silo' . $cols . '">';
	// En el móvil solo la primera va a todo el ancho; las demás son filas con miniatura de 6,5rem
	foreach ( array_values( $list ) as $i => $p ) { $o .= jm_story( $p, 'md', array( 'kicker' => false, 'dek' => true, 'sizes' => '(min-width: 1100px) 330px, (min-width: 640px) 45vw, ' . ( $i ? '104px' : '100vw' ) ) ); }
	return $o . '</div>' . $note;
} );

add_shortcode( 'jm_guias', function () {
	$o = '';
	foreach ( jm_data( 'temas' ) as $slug ) {
		$term = get_category_by_slug( $slug );
		if ( ! $term ) { continue; }
		$c     = jm_data( 'cats' )[ $slug ];
		$list  = jm_stories( $slug, 60, array(), false, false );
		$items = '';
		foreach ( $list as $p ) {
			$thumb = get_the_post_thumbnail( $p, 'thumbnail', array( 'loading' => 'lazy', 'alt' => '' ) );
			$inner = ( $thumb ? '<span class="jm-topic__thumb">' . $thumb . '</span>' : '' )
				. '<span class="jm-topic__t">' . esc_html( get_the_title( $p ) ) . '</span><small>' . esc_html( get_the_excerpt( $p ) ) . '</small>';
			$items .= '<li><a href="' . esc_url( get_permalink( $p ) ) . '">' . $inner . jm_icon( 'arrow' ) . '</a></li>';
		}
		$o .= '<section class="jm-topic" id="' . esc_attr( $slug ) . '" aria-labelledby="t-' . esc_attr( $slug ) . '">'
			. '<div class="jm-topic__head"><span class="jm-tile__icon">' . jm_icon( $c['icon'] ) . '</span><h2 id="t-' . esc_attr( $slug ) . '"><a href="' . esc_url( home_url( '/' . $slug . '/' ) ) . '">' . esc_html( $term->name ) . '</a></h2>'
			. '<p>' . esc_html( $c['lead'] ) . '</p><a class="jm-link-arrow" href="' . esc_url( home_url( '/' . $slug . '/' ) ) . '">Ir al tema' . jm_icon( 'arrow' ) . '</a></div>'
			. ( $items ? '<ul class="jm-topic__list">' . $items . '</ul>' : '' ) . jm_prep_note( jm_prep_count( $slug ) ) . '</section>';
	}
	return $o;
} );

/* ------------------------------------------------------------------
 * 8b. CALIDAD PARA GOOGLE Y ADSENSE
 * ------------------------------------------------------------------ */
// Las zonas de redacción y los huecos de anuncio vacíos solo existen para el editor conectado:
// a los lectores y a Google no se les envían (antes solo se ocultaban con CSS).
add_filter( 'the_content', function ( $html ) {
	if ( is_user_logged_in() ) { return $html; }
	$html = preg_replace( '#<section class="jm-zone"[^>]*>.*?</section>#s', '', $html );
	return preg_replace_callback( '#<aside class="jm-ad"[^>]*>.*?</aside>#s', function ( $m ) {
		return false !== strpos( $m[0], 'adsbygoogle' ) ? $m[0] : '';
	}, $html );
}, 25 );

/*
 * Imagen para compartir (WhatsApp, Facebook, X) con el diseño «Azul confianza». Rank Math tiene guardada la
 * imagen anterior como imagen por defecto; al pintar las etiquetas se cambia por la nueva (misma medida, 1200 × 630).
 */
function jm_og_nueva( $url ) {
	$viejas = array( content_url( '/uploads/2026/09/og-jubilometro.jpg' ), content_url( '/uploads/2026/09/og-jubilometro-pino.jpg' ) );
	return ( is_string( $url ) && in_array( $url, $viejas, true ) ) ? JM_THEME_URI . '/assets/img/og-jubilometro.jpg?v=' . JM_THEME_VER : $url;
}
foreach ( array( 'rank_math/opengraph/facebook/og_image', 'rank_math/opengraph/facebook/og_image_secure_url', 'rank_math/opengraph/twitter/twitter_image' ) as $jm_f ) {
	add_filter( $jm_f, 'jm_og_nueva' );
}

/*
 * Tablas en el móvil. Cada celda lleva el nombre de su columna (data-label) y las tablas de tres o más
 * columnas que no caben en la pantalla se leen como fichas, una por fila: antes la última columna quedaba
 * cortada en el borde y había que adivinar que se podía deslizar. Para saber si cabe se estima su ancho
 * mínimo con la palabra más larga de cada columna (7,3 px por carácter y 29 px de márgenes por columna,
 * ajustado midiendo en el navegador las 131 tablas de la web): más de 325 px no cabe en un móvil de 390
 * (fichas por debajo de 600 px); más de 260 px, en uno de 360 o menos (fichas por debajo de 380 px).
 * Las tablas de cifras breves se compactan primero (6,9 px por carácter y 16 px por columna).
 * La tabla ordenable de datos (data-sort) no se toca.
 */
add_filter( 'the_content', 'jm_tablas_moviles', 30 );
function jm_tablas_moviles( $html ) {
	if ( false === strpos( $html, '<table class="jm-table"' ) ) { return $html; }
	return preg_replace_callback( '#<table class="jm-table"([^>]*)>(.*?)</table>#s', function ( $m ) {
		if ( false !== strpos( $m[2], 'data-sort' ) || ! preg_match( '#<thead>(.*?)</thead>#s', $m[2], $h ) ) { return $m[0]; }
		$texto  = function ( $t ) { return trim( preg_replace( '/[\s\x{00A0}]+/u', ' ', html_entity_decode( wp_strip_all_tags( $t ), ENT_QUOTES, 'UTF-8' ) ) ); };
		$larga  = function ( $t ) { $n = 0; foreach ( explode( ' ', $t ) as $w ) { $n = max( $n, mb_strlen( $w ) ); } return $n; };
		preg_match_all( '#<th\b[^>]*>(.*?)</th>#s', $h[1], $ths );
		$labels = array_map( $texto, $ths[1] );
		if ( count( $labels ) < 3 ) { return $m[0]; }
		$maxw  = array_map( $larga, $labels );
		$maxc  = array(); // largo de la celda entera: en las tablas de cifras no se parte («1.922,96 €»)
		$corta = true; // todas las celdas (salvo la primera columna) son cifras o textos breves
		$body  = preg_replace_callback( '#<tbody>(.*?)</tbody>#s', function ( $b ) use ( $labels, $texto, $larga, &$maxw, &$maxc, &$corta ) {
			return '<tbody>' . preg_replace_callback( '#<tr\b[^>]*>.*?</tr>#s', function ( $tr ) use ( $labels, $texto, $larga, &$maxw, &$maxc, &$corta ) {
				$i = 0;
				return preg_replace_callback( '#<(td|th)\b([^>]*)>(.*?)</\1>#s', function ( $c ) use ( $labels, $texto, $larga, &$maxw, &$maxc, &$corta, &$i ) {
					$k          = $i++;
					$t          = $texto( $c[3] );
					$maxw[ $k ] = max( $maxw[ $k ] ?? 0, $larga( $t ) );
					$maxc[ $k ] = max( $maxc[ $k ] ?? 0, mb_strlen( $t ) );
					if ( $k > 0 && mb_strlen( $t ) > 12 ) { $corta = false; }
					if ( ! isset( $labels[ $k ] ) || '' === $labels[ $k ] || false !== strpos( $c[2], 'data-label' ) ) { return $c[0]; }
					return '<' . $c[1] . $c[2] . ' data-label="' . esc_attr( $labels[ $k ] ) . '">' . $c[3] . '</' . $c[1] . '>';
				}, $tr[0] );
			}, $b[1] ) . '</tbody>';
		}, $m[2] );
		// Las de cifras breves se compactan (letra y márgenes menores) y solo pasan a fichas si ni así caben
		if ( $corta ) {
			foreach ( $maxw as $k => $n ) { if ( $k > 0 ) { $maxw[ $k ] = max( $n, $maxc[ $k ] ?? 0 ); } }
		}
		$ancho = $corta ? 6.9 * array_sum( $maxw ) + 16 * count( $maxw ) : 7.3 * array_sum( $maxw ) + 29 * count( $maxw );
		// Una tabla larga de cifras se compara mejor como tabla: se queda compacta y, si no cabe, se desliza
		$muchas = $corta && substr_count( $body, '<tr' ) > 8;
		$clase = $muchas ? '' : ( $ancho > 325 ? ' jm-table--fichas' : ( $ancho > 260 ? ' jm-table--fichas-sm' : '' ) );
		$clase .= $corta ? ' jm-table--compacta' : '';
		return '<table class="jm-table' . $clase . '"' . $m[1] . '>' . $body . '</table>';
	}, $html );
}

/*
 * AdSense (anuncios automáticos). Se activa guardando el ID de editor (ca-pub-…) en la opción
 * jm_adsense_client por la API: POST /wp/v2/settings {"jm_adsense_client": "ca-pub-…"}.
 * - La etiqueta google-adsense-account va en todas las páginas (verificación del sitio).
 * - El código de anuncios no se carga en las calculadoras, las páginas legales, el buscador ni la 404:
 *   así no hay anuncios junto a los botones de calcular (clics accidentales) ni en páginas sin contenido propio.
 * - /ads.txt: desde el 28/10/2026 hay un archivo fijo en la raíz del hosting (copia en publicacion/hosting/ads.txt),
 *   que el servidor entrega sin pasar por WordPress. Si se borra, el tema lo genera con el ID.
 * - Los ajustes del tema van en su propio grupo («jubilometro»), no en «general»: WordPress vacía al guardar
 *   Ajustes › Generales todas las opciones de ese grupo que no tienen campo en la página.
 */
add_action( 'init', function () {
	register_setting( 'jubilometro', 'jm_adsense_client', array(
		'type'              => 'string',
		'default'           => '',
		'show_in_rest'      => true,
		'description'       => 'ID de editor de AdSense (ca-pub-…)',
		'sanitize_callback' => function ( $v ) {
			$v = trim( (string) $v );
			return preg_match( '/^ca-pub-\d{10,20}$/', $v ) ? $v : '';
		},
	) );
} );
// Al guardar o cambiar el ID se vacía la caché de LiteSpeed: si no, las páginas y /ads.txt
// (que antes daba 404) seguirían saliendo de la caché sin la etiqueta ni el código.
add_action( 'add_option_jm_adsense_client', 'jm_adsense_purge' );
add_action( 'update_option_jm_adsense_client', 'jm_adsense_purge' );
function jm_adsense_purge() { do_action( 'litespeed_purge_all' ); }
function jm_adsense_client() {
	$c = get_option( 'jm_adsense_client', '' );
	return is_string( $c ) && preg_match( '/^ca-pub-\d{10,20}$/', $c ) ? $c : '';
}
function jm_ads_allowed() {
	if ( is_404() || is_search() ) { return false; }
	if ( is_page() ) {
		$id  = get_queried_object_id();
		$anc = get_post_ancestors( $id );
		$top = get_post_field( 'post_name', $anc ? end( $anc ) : $id );
		if ( 'calculadoras' === $top ) { return false; }
		if ( in_array( get_post_field( 'post_name', $id ), array( 'aviso-legal', 'politica-privacidad', 'politica-cookies', 'contacto', 'descargo-responsabilidad', 'accesibilidad' ), true ) ) { return false; }
	}
	return true;
}
add_action( 'wp_head', function () {
	$c = jm_adsense_client();
	if ( ! $c ) { return; }
	printf( '<meta name="google-adsense-account" content="%s">' . "\n", esc_attr( $c ) );
	if ( jm_ads_allowed() ) {
		printf( '<script async src="%s" crossorigin="anonymous" data-no-optimize="1" data-no-defer="1"></script>' . "\n", esc_url( 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=' . $c ) );
	}
}, 2 );
add_action( 'init', function () {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtok( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), '?' ) : '';
	if ( '/ads.txt' !== $uri ) { return; }
	$c = jm_adsense_client();
	if ( ! $c ) { return; }
	nocache_headers();
	header( 'Content-Type: text/plain; charset=utf-8' );
	echo 'google.com, ' . esc_html( substr( $c, 3 ) ) . ', DIRECT, f08c47fec0942fa0' . "\n"; // phpcs:ignore
	exit;
}, 1 );

/*
 * Google Analytics 4. Se activa guardando el ID de medición (G-…) en la opción jm_ga4_id
 * por la API: POST /wp/v2/settings {"jm_ga4_id": "G-…"}.
 * Aquí solo se deja el ID en la página: jubilometro.js carga gtag.js cuando el aviso de privacidad
 * de Google da permiso (finalidades 1 y 8 del TCF y el proveedor Google, 755) o cuando el RGPD no
 * se aplica. Sin aviso en la página (calculadoras y legales no cargan AdSense) no se carga.
 * No se cuenta a los editores conectados. No cambia cómo ni cuándo carga AdSense.
 */
add_action( 'init', function () {
	register_setting( 'jubilometro', 'jm_ga4_id', array(
		'type'              => 'string',
		'default'           => '',
		'show_in_rest'      => true,
		'description'       => 'ID de medición de Google Analytics 4 (G-…)',
		'sanitize_callback' => function ( $v ) {
			$v = strtoupper( trim( (string) $v ) );
			return preg_match( '/^G-[A-Z0-9]{6,14}$/', $v ) ? $v : '';
		},
	) );
} );
add_action( 'add_option_jm_ga4_id', 'jm_adsense_purge' );
add_action( 'update_option_jm_ga4_id', 'jm_adsense_purge' );
function jm_ga4_id() {
	$c = get_option( 'jm_ga4_id', '' );
	return is_string( $c ) && preg_match( '/^G-[A-Z0-9]{6,14}$/', $c ) ? $c : '';
}
add_action( 'wp_head', function () {
	$id = jm_ga4_id();
	if ( ! $id || current_user_can( 'edit_posts' ) ) { return; }
	printf( '<script data-no-optimize="1">window.jmGA=%s;</script>' . "\n", wp_json_encode( $id ) );
}, 3 );

// Un tema (página pilar) se indexa cuando tiene al menos 3 guías publicadas; mientras, noindex y fuera del sitemap
function jm_thin_page( $id ) {
	$slug = get_post_field( 'post_name', $id );
	if ( wp_get_post_parent_id( $id ) ) { return false; }
	if ( ! in_array( $slug, jm_data( 'temas' ), true ) ) { return false; }
	$term = get_category_by_slug( $slug );
	return ! $term || (int) $term->count < 3;
}
add_filter( 'rank_math/frontend/robots', function ( $robots ) {
	if ( is_page() && jm_thin_page( get_queried_object_id() ) ) {
		$robots['index']  = 'noindex';
		$robots['follow'] = 'follow';
	}
	return $robots;
} );
add_filter( 'rank_math/sitemap/entry', function ( $url, $type, $object ) {
	if ( 'post' === $type && isset( $object->ID, $object->post_type ) && 'page' === $object->post_type && jm_thin_page( $object->ID ) ) { return false; }
	return $url;
}, 10, 3 );

// La descripción de /guias/ dice siempre el número real de guías publicadas
add_filter( 'rank_math/frontend/description', function ( $desc ) {
	if ( is_page( 'guias' ) ) {
		$n    = (int) wp_count_posts( 'post' )->publish;
		$desc = preg_replace( '/\b\d+ guías\b/u', $n . ' guías', (string) $desc );
	}
	return $desc;
} );

// Textos de Rank Math para WhatsApp y Slack, en castellano
add_filter( 'rank_math/opengraph/slack_enhanced_data', function ( $data ) {
	$out = array();
	foreach ( (array) $data as $k => $v ) {
		$k = strtr( $k, array( 'Written by' => 'Escrito por', 'Time to read' => 'Tiempo de lectura', 'Price' => 'Precio' ) );
		$out[ $k ] = is_string( $v ) ? preg_replace( array( '/\bminutes?\b/', '/\bLess than a minute\b/' ), array( 'min', 'Menos de un minuto' ), $v ) : $v;
	}
	return $out;
} );

// Foto del autor (assets/img/<photo>-160.webp y -320.webp); si no hay foto, sus iniciales
function jm_author_avatar() {
	$a = jm_data( 'author' );
	if ( empty( $a['photo'] ) ) { return '<span class="jm-avatar" aria-hidden="true">' . esc_html( $a['initials'] ) . '</span>'; }
	$src = JM_THEME_URI . '/assets/img/' . $a['photo'];
	return '<span class="jm-avatar" aria-hidden="true"><img src="' . esc_url( $src . '-160.webp' ) . '" srcset="' . esc_url( $src . '-320.webp' ) . ' 2x" width="160" height="160" alt="" decoding="async"></span>';
}

// Datos estructurados: una sola persona (Pau Lobato) como autor y revisor, y la organización con web y logo
add_filter( 'rank_math/json_ld', function ( $data ) {
	$pid    = home_url( '/sobre-nosotros/#pau-lobato' );
	$person = array( '@type' => 'Person', '@id' => $pid, 'name' => 'Pau Lobato', 'jobTitle' => 'Fundador y editor de Jubilómetro', 'description' => (string) jm_data( 'author' )['bio'], 'image' => JM_THEME_URI . '/assets/img/pau-lobato-800.webp', 'url' => home_url( '/sobre-nosotros/' ), 'worksFor' => array( '@id' => home_url( '/#organization' ) ) );
	$org    = array(
		'@type' => 'Organization',
		'@id'   => home_url( '/#organization' ),
		'name'  => 'Jubilómetro',
		'url'   => home_url( '/' ),
		'logo'  => array( '@type' => 'ImageObject', '@id' => home_url( '/#logo' ), 'url' => JM_THEME_URI . '/assets/img/logo-jubilometro.png', 'width' => 512, 'height' => 512, 'caption' => 'Jubilómetro' ),
		'image' => array( '@id' => home_url( '/#logo' ) ),
	);
	$has_person = false;
	foreach ( $data as $k => $node ) {
		if ( ! is_array( $node ) || empty( $node['@type'] ) ) { continue; }
		$type = (array) $node['@type'];
		if ( in_array( 'Person', $type, true ) ) { $data[ $k ] = $person; $has_person = true; }
		if ( in_array( 'Organization', $type, true ) ) { $data[ $k ] = array_merge( $node, $org ); }
		if ( isset( $node['author'] ) ) { $data[ $k ]['author'] = array( '@id' => $pid, 'name' => 'Pau Lobato' ); }
		if ( isset( $node['reviewedBy'] ) ) { $data[ $k ]['reviewedBy'] = array( '@id' => $pid ); }
		if ( isset( $node['isAccessibleForFree'] ) ) { $data[ $k ]['isAccessibleForFree'] = 'True'; }
	}
	// Páginas (temas, calculadoras, sobre nosotros…): Rank Math solo pone la miga de pan; se completa el grafo
	if ( is_page() && ! is_front_page() && ! isset( $data['WebPage'] ) ) {
		$id    = get_queried_object_id();
		$about = 'sobre-nosotros' === get_post_field( 'post_name', $id );
		$data['publisher'] = $org;
		$data['WebSite']   = array( '@type' => 'WebSite', '@id' => home_url( '/#website' ), 'url' => home_url( '/' ), 'name' => 'Jubilómetro', 'publisher' => array( '@id' => home_url( '/#organization' ) ), 'inLanguage' => 'es' );
		$data['WebPage']   = array(
			'@type'        => $about ? 'AboutPage' : 'WebPage',
			'@id'          => get_permalink( $id ) . '#webpage',
			'url'          => get_permalink( $id ),
			'name'         => wp_strip_all_tags( get_the_title( $id ) ),
			'isPartOf'     => array( '@id' => home_url( '/#website' ) ),
			'inLanguage'   => 'es',
			'dateModified' => get_the_modified_date( 'c', $id ),
			'breadcrumb'   => array( '@id' => get_permalink( $id ) . '#breadcrumb' ),
		);
		$legal = array( 'aviso-legal', 'politica-privacidad', 'politica-cookies', 'descargo-responsabilidad', 'accesibilidad', 'contacto' );
		if ( $about ) { $data['WebPage']['mainEntity'] = array( '@id' => $pid ); }
		if ( ! jm_thin_page( $id ) && ! in_array( get_post_field( 'post_name', $id ), $legal, true ) ) { $data['WebPage']['reviewedBy'] = array( '@id' => $pid ); }
		$data['Person'] = $person;
		$has_person     = true;
	}
	// Si algo cita a Pau pero su ficha no está en la página, se añade
	if ( ! $has_person && false !== strpos( (string) wp_json_encode( $data, JSON_UNESCAPED_SLASHES ), $pid ) ) { $data['Person'] = $person; }
	// Portada: imagen de marca en lugar de la primera foto que encuentre
	if ( is_front_page() ) {
		$img = home_url( '/#primaryimage' );
		foreach ( $data as $k => $node ) {
			if ( ! is_array( $node ) || empty( $node['@type'] ) ) { continue; }
			if ( 'ImageObject' === $node['@type'] ) {
				$data[ $k ] = array( '@type' => 'ImageObject', '@id' => $img, 'url' => JM_THEME_URI . '/assets/img/og-jubilometro.jpg', 'width' => 1200, 'height' => 630, 'caption' => 'Jubilómetro: jubilación y pensiones, con las cuentas claras', 'inLanguage' => 'es' );
			}
			if ( isset( $node['primaryImageOfPage'] ) ) { $data[ $k ]['primaryImageOfPage'] = array( '@id' => $img ); }
			if ( isset( $node['image'] ) && is_array( $node['image'] ) && isset( $node['image']['@id'] ) && false !== strpos( $node['image']['@id'], 'unsplash' ) ) { $data[ $k ]['image'] = array( '@id' => $img ); }
		}
	}
	return $data;
}, 120 );

// Calculadoras sin ficha de aplicación en Rank Math (las añadidas después, como el simulador o la subida):
// se completa con el nombre y la descripción de inc/data.json, igual que la de las demás calculadoras
add_filter( 'rank_math/json_ld', function ( $data ) {
	if ( ! is_page() ) { return $data; }
	$id    = get_queried_object_id();
	$slug  = get_post_field( 'post_name', $id );
	$par   = wp_get_post_parent_id( $id );
	$calcs = jm_data( 'calcs' );
	if ( ! $par || 'calculadoras' !== get_post_field( 'post_name', $par ) || empty( $calcs[ $slug ] ) ) { return $data; }
	foreach ( $data as $node ) {
		if ( is_array( $node ) && ! empty( $node['@type'] ) && in_array( 'WebApplication', (array) $node['@type'], true ) ) { return $data; }
	}
	$url                    = get_permalink( $id );
	$data['WebApplication'] = array(
		'@type'               => 'WebApplication',
		'@id'                 => $url . '#app',
		'name'                => $calcs[ $slug ]['name'],
		'description'         => $calcs[ $slug ]['desc'],
		'url'                 => $url,
		'applicationCategory' => 'FinanceApplication',
		'operatingSystem'     => 'Web',
		'browserRequirements' => 'Requiere JavaScript',
		'inLanguage'          => 'es-ES',
		'isAccessibleForFree' => 'True',
		'offers'              => array( '@type' => 'Offer', 'price' => '0', 'priceCurrency' => 'EUR' ),
		'dateModified'        => get_the_modified_date( 'c', $id ),
		'citation'            => array( 'https://www.boe.es/buscar/act.php?id=BOE-A-2015-11724', 'https://www.seg-social.es' ),
		'publisher'           => array( '@id' => home_url( '/#organization' ) ),
	);
	return $data;
}, 125 );

/*
 * Tablas de datos (páginas hijas de /datos/):
 *   - /datos/<tabla>.csv sirve la tabla en CSV. Se lee de la propia página publicada (atributos data-jm-csv-head
 *     y data-csv que escriben las herramientas de herramientas/datos/), así que nunca se desfasa de lo que se ve.
 *   - Ficha Dataset en los datos estructurados de cada tabla, con ese CSV como descarga (Google Dataset Search).
 */
function jm_tabla_datos( $slug ) {
	if ( ! preg_match( '/^[a-z0-9-]+$/', (string) $slug ) ) { return null; }
	$page = get_page_by_path( 'datos/' . $slug );
	if ( ! $page || 'publish' !== $page->post_status ) { return null; }
	$html = (string) $page->post_content;
	if ( ! preg_match( '#data-jm-csv-head="([^"]+)"#', $html, $h ) || ! preg_match_all( '#<tr\b([^>]*\sdata-csv="[^"]*"[^>]*)>#', $html, $m ) ) { return null; }
	$attr  = function ( $tag, $n ) { return preg_match( '#\sdata-' . $n . '="([^"]*)"#', $tag, $x ) ? html_entity_decode( $x[1], ENT_QUOTES, 'UTF-8' ) : null; };
	$filas = array( explode( '|', html_entity_decode( $h[1], ENT_QUOTES, 'UTF-8' ) ) );
	foreach ( $m[1] as $tag ) {
		$fila = array();
		foreach ( array( 'label', 'ccaa-label' ) as $n ) {
			if ( null !== $attr( $tag, $n ) ) { $fila[] = $attr( $tag, $n ); }
		}
		$filas[] = array_merge( $fila, explode( '|', (string) $attr( $tag, 'csv' ) ) );
	}
	return $filas;
}
add_action( 'init', function () {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtok( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), '?' ) : '';
	if ( ! preg_match( '#^/datos/([a-z0-9-]+)\.csv$#', (string) $uri, $m ) ) { return; }
	$filas = jm_tabla_datos( $m[1] );
	if ( ! $filas ) { return; } // sin tabla: sigue su curso y da 404
	nocache_headers();
	header( 'Content-Type: text/csv; charset=utf-8' );
	header( 'Content-Disposition: inline; filename="' . $m[1] . '.csv"' );
	header( 'X-Robots-Tag: noindex' );
	header( 'Access-Control-Allow-Origin: *' );
	$out = fopen( 'php://output', 'w' );
	foreach ( $filas as $f ) { fputcsv( $out, $f, ',', '"', '' ); }
	fclose( $out );
	exit;
}, 1 );
add_filter( 'rank_math/json_ld', function ( $data ) {
	if ( ! is_page() ) { return $data; }
	$id  = get_queried_object_id();
	$par = wp_get_post_parent_id( $id );
	if ( ! $par || 'datos' !== get_post_field( 'post_name', $par ) ) { return $data; }
	// La ficha antigua de Rank Math (con un CSV que no existía) se sustituye por esta
	foreach ( $data as $k => $node ) {
		if ( is_array( $node ) && ! empty( $node['@type'] ) && in_array( 'Dataset', (array) $node['@type'], true ) ) { unset( $data[ $k ] ); }
	}
	$fichas = array(
		'pension-media-provincia'             => array( 'Pensión media de jubilación por provincia en España', array( 'Número de pensiones de jubilación', 'Pensión media de jubilación (euros al mes)', 'Diferencia con la media nacional (euros al mes)' ) ),
		'evolucion-pension-media'             => array( 'Evolución de la pensión media en España desde 2010', array( 'Pensión media de jubilación, viudedad, incapacidad permanente y de todo el sistema (euros al mes)', 'Número de pensiones de jubilación' ) ),
		'complemento-minimos-provincia'       => array( 'Pensiones con complemento a mínimos por provincia en España', array( 'Número de pensiones con complemento a mínimos', 'Porcentaje sobre el total de pensiones de mujeres, de hombres y total' ) ),
		'complemento-brecha-genero-provincia' => array( 'Pensiones con complemento de brecha de género por provincia en España', array( 'Número de pensiones con el complemento', 'Importe medio del complemento (euros al mes)', 'Pensiones por número de hijos' ) ),
		'pension-media-regimen'               => array( 'Pensión media por régimen de la Seguridad Social en España', array( 'Número de pensiones por régimen y clase', 'Pensión media por régimen y clase (euros al mes)' ) ),
	);
	$slug = get_post_field( 'post_name', $id );
	// Una tabla nueva sin ficha propia: el título de la página y las columnas de su CSV
	if ( empty( $fichas[ $slug ] ) ) {
		$cols = jm_tabla_datos( $slug );
		if ( ! $cols ) { return $data; }
		$fichas[ $slug ] = array( wp_strip_all_tags( get_the_title( $id ) ) . ' en España', array_values( array_diff( $cols[0], array( 'provincia', 'comunidad', 'regimen', 'anio', 'mes' ) ) ) );
	}
	$html  = (string) get_post_field( 'post_content', $id );
	$url   = get_permalink( $id );
	$meses = array_flip( array( 'enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre' ) );
	$fin   = preg_match( '#<h1>[^<]*\((\p{L}+) de (\d{4})\)</h1>#u', $html, $x ) && isset( $meses[ $x[1] ] ) ? sprintf( '%d-%02d', $x[2], $meses[ $x[1] ] + 1 ) : '';
	$desc  = trim( (string) get_post_meta( $id, 'rank_math_description', true ) );
	$ds    = array(
		'@type'               => 'Dataset',
		'@id'                 => $url . '#dataset',
		'name'                => $fichas[ $slug ][0],
		'description'         => strlen( $desc ) >= 50 ? $desc : wp_strip_all_tags( get_the_excerpt( $id ) ),
		'url'                 => $url,
		'inLanguage'          => 'es-ES',
		'creator'             => array( '@id' => home_url( '/#organization' ) ),
		'isBasedOn'           => preg_match( '#href="(https://revista\.seg-social\.es/[^"]+)"#', $html, $f ) ? html_entity_decode( $f[1], ENT_QUOTES, 'UTF-8' ) : 'https://www.seg-social.es',
		'license'             => 'https://creativecommons.org/licenses/by/4.0/',
		'isAccessibleForFree' => true,
		'spatialCoverage'     => array( '@type' => 'Place', 'name' => 'España' ),
		'dateModified'        => get_the_modified_date( 'c', $id ),
		'variableMeasured'    => $fichas[ $slug ][1],
	);
	if ( $fin ) { $ds['temporalCoverage'] = 'evolucion-pension-media' === $slug ? '2010-12/' . $fin : $fin; }
	if ( jm_tabla_datos( $slug ) ) {
		$ds['distribution'] = array( array( '@type' => 'DataDownload', 'encodingFormat' => 'text/csv', 'contentUrl' => home_url( '/datos/' . $slug . '.csv' ) ) );
	}
	$data['Dataset'] = $ds;
	return $data;
}, 126 );

/* ------------------------------------------------------------------
 * 8c. CALCULADORAS PARA OTRAS WEBS
 *     /calculadoras/<calculadora>/insertar/ sirve solo la calculadora, sin menús, anuncios ni
 *     rastreadores, para que blogs, asociaciones o medios la pongan en un iframe. Lleva noindex y
 *     canonical a la calculadora (no compite con ella en Google) y es la única URL que se puede
 *     enmarcar desde otra web: el resto sigue con X-Frame-Options: SAMEORIGIN.
 *     El código para copiar está en /calculadoras/para-tu-web/. El script opcional
 *     assets/js/insertar.js ajusta la altura del iframe en la web que lo inserta.
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	add_rewrite_endpoint( 'insertar', EP_PAGES );
	// Las reglas nuevas se guardan una vez por versión del tema (sin tocar el panel de enlaces permanentes)
	if ( get_option( 'jm_rewrite_ver' ) !== JM_THEME_VER ) {
		flush_rewrite_rules( false );
		update_option( 'jm_rewrite_ver', JM_THEME_VER, false );
	}
}, 20 );
// /insertar/ llega sin valor: se marca para poder distinguirlo de una página normal
add_filter( 'request', function ( $vars ) {
	if ( isset( $vars['insertar'] ) ) { $vars['insertar'] = '1'; }
	return $vars;
} );
function jm_calc_section( $post ) {
	$html = ( $post instanceof WP_Post && 'page' === $post->post_type ) ? (string) $post->post_content : '';
	return preg_match( '#<section aria-label="Calculadora">.*?</section>#s', $html, $m ) ? $m[0] : '';
}
add_action( 'template_redirect', function () {
	if ( '1' !== get_query_var( 'insertar' ) ) { return; }
	$post = get_queried_object();
	$calc = jm_calc_section( $post );
	if ( '' === $calc ) {
		wp_safe_redirect( $post instanceof WP_Post ? get_permalink( $post ) : home_url( '/' ), 301 );
		exit;
	}
	$url    = get_permalink( $post );
	$titulo = wp_strip_all_tags( get_the_title( $post ) );
	header_remove( 'X-Frame-Options' );
	header( 'Content-Security-Policy: frame-ancestors *' );
	header( 'X-Robots-Tag: noindex, follow' );
	header( 'Content-Type: text/html; charset=utf-8' );
	$fuentes = '';
	foreach ( array( 'newsreader-normal-latin', 'public-sans-normal-latin' ) as $f ) {
		$fuentes .= sprintf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( JM_THEME_URI . '/assets/fonts/' . $f . '.woff2' ) );
	}
	echo '<!doctype html>' . "\n" . '<html lang="es">' . "\n" . '<head>' . "\n"
		. '<meta charset="utf-8">' . "\n"
		. '<meta name="viewport" content="width=device-width, initial-scale=1">' . "\n"
		. '<title>' . esc_html( $titulo . ' · Jubilómetro' ) . '</title>' . "\n"
		. '<meta name="robots" content="noindex, follow">' . "\n"
		. '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n"
		. '<base target="_blank">' . "\n"
		. $fuentes // phpcs:ignore
		. '<link rel="stylesheet" href="' . esc_url( JM_THEME_URI . '/assets/css/jubilometro.css?ver=' . JM_THEME_VER ) . '">' . "\n"
		. '<style>html{background:var(--jm-paper)}body.jm-embed{margin:0}.jm-embed main{padding:.75rem 0 .25rem}.jm-embed .jm-wrap{padding-inline:.75rem}'
		. '.jm-embed__pie{display:flex;flex-wrap:wrap;justify-content:space-between;gap:.25rem 1rem;margin:.75rem .75rem 0;padding-top:.6rem;border-top:1px solid var(--jm-line-2);font-size:.875rem;color:var(--jm-muted)}'
		. '.jm-embed__pie a{color:var(--jm-accent-strong);font-weight:700}</style>' . "\n"
		. '</head>' . "\n" . '<body class="jm-live jm-embed">' . "\n"
		. jm_part( 'sprite' ) // phpcs:ignore
		. '<main>' . "\n" . $calc . "\n" // phpcs:ignore
		. '<p class="jm-embed__pie"><span>Calculadora de <a href="' . esc_url( $url ) . '">Jubilómetro</a>, con las cifras oficiales actualizadas</span>'
		. '<a href="' . esc_url( $url ) . '">Ver la explicación completa</a></p>' . "\n"
		. '</main>' . "\n"
		. '<script src="' . esc_url( JM_THEME_URI . '/assets/js/calculadoras.js?ver=' . JM_THEME_VER ) . '" defer></script>' . "\n"
		// Altura para el script opcional de la web que inserta la calculadora
		// (se repite al cargar y cuando la web lo pide, porque su script puede llegar después que la calculadora)
		. '<script>(function(){var u=0,m=document.querySelector("main");function s(f){var h=Math.ceil(m.getBoundingClientRect().bottom+window.scrollY+8);'
		. 'if((f||h!==u)&&window.parent!==window){u=h;window.parent.postMessage({jubilometro:"alto",alto:h},"*")}}'
		. 'if(window.ResizeObserver){new ResizeObserver(function(){s()}).observe(m)}window.addEventListener("load",function(){s(1)});'
		. '[400,1500,4000,8000].forEach(function(t){setTimeout(function(){s(1)},t)});'
		. 'window.addEventListener("message",function(e){if(e.data&&e.data.jubilometro==="pide-alto")s(1)})})();</script>' . "\n"
		. '</body>' . "\n" . '</html>';
	exit;
}, 1 );

// Debajo de cada calculadora, la invitación a ponerla en otra web
add_filter( 'the_content', function ( $html ) {
	if ( ! is_page() || false === strpos( $html, '<section aria-label="Calculadora">' ) ) { return $html; }
	$slug = get_post_field( 'post_name', get_queried_object_id() );
	$link = '<div class="jm-wrap"><p class="jm-insertar"><svg class="jm-i" aria-hidden="true"><use href="#i-link"/></svg>'
		. '<span>¿Tienes una web o un blog? <a href="/calculadoras/para-tu-web/#' . esc_attr( $slug ) . '">Pon esta calculadora gratis en tu web</a>.</span></p></div>';
	return preg_replace( '#(<section aria-label="Calculadora">.*?)(</section>)#s', '$1' . $link . '$2', $html, 1 );
}, 28 );

/* ------------------------------------------------------------------
 * 8d. BUSCADORES CON IA (ChatGPT, Perplexity, Claude, Gemini, Copilot)
 *     - FAQPage: las preguntas frecuentes que ya se ven en cada guía o calculadora, también como datos estructurados.
 *     - /llms.txt: resumen de la web para los asistentes de IA (llmstxt.org), generado con las guías publicadas.
 *     - IndexNow: avisa a Bing (y con él a Copilot y a la búsqueda de ChatGPT) de cada página nueva o cambiada.
 * ------------------------------------------------------------------ */
add_filter( 'rank_math/json_ld', function ( $data ) {
	if ( ! is_singular( array( 'post', 'page' ) ) ) { return $data; }
	$html = (string) get_post_field( 'post_content', get_queried_object_id() );
	if ( ! preg_match_all( '#<details><summary>(.*?)<svg[^>]*>.*?</svg></summary><div>(.*?)</div></details>#s', $html, $m, PREG_SET_ORDER ) || count( $m ) < 2 ) { return $data; }
	$texto = function ( $s ) { return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( $s ), ENT_QUOTES, 'UTF-8' ) ) ); };
	$qs    = array();
	foreach ( array_slice( $m, 0, 12 ) as $q ) {
		$qs[] = array( '@type' => 'Question', 'name' => $texto( $q[1] ), 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => $texto( $q[2] ) ) );
	}
	$url             = get_permalink( get_queried_object_id() );
	$data['FAQPage'] = array( '@type' => 'FAQPage', '@id' => $url . '#preguntas-frecuentes', 'url' => $url, 'inLanguage' => 'es', 'isPartOf' => array( '@id' => $url . '#webpage' ), 'mainEntity' => $qs );
	return $data;
}, 130 );

function jm_llms_txt() {
	$cache = get_transient( 'jm_llms_txt' );
	if ( is_string( $cache ) && '' !== $cache ) { return $cache; }
	$base = untrailingslashit( home_url() );
	$fmt  = function ( $id ) {
		$t = (string) get_post_meta( $id, 'rank_math_title', true );
		$t = '' !== $t && false === strpos( $t, '%' ) ? $t : get_the_title( $id );
		$d = (string) get_post_meta( $id, 'rank_math_description', true );
		$d = '' !== $d ? $d : get_the_excerpt( $id );
		$c = function ( $s ) { return trim( preg_replace( '/\s+/u', ' ', html_entity_decode( wp_strip_all_tags( (string) $s ), ENT_QUOTES, 'UTF-8' ) ) ); };
		return '- [' . $c( $t ) . '](' . get_permalink( $id ) . ')' . ( '' !== $c( $d ) ? ': ' . $c( $d ) : '' );
	};
	$posts = get_posts( array( 'post_type' => 'post', 'post_status' => 'publish', 'posts_per_page' => -1, 'orderby' => 'date', 'order' => 'ASC', 'no_found_rows' => true ) );
	$ultima = 0;
	foreach ( $posts as $p ) { $ultima = max( $ultima, (int) get_post_modified_time( 'U', true, $p ) ); }
	$o  = "# Jubilómetro\n\n";
	$o .= '> Guías y calculadoras gratuitas sobre jubilación y pensiones en España: edad de jubilación, cuánto se cobra, viudedad, incapacidad, ayudas, dependencia, IMSERSO e impuestos. Cada cifra se comprueba en el BOE, la Seguridad Social y la Agencia Tributaria, y cada guía indica la norma aplicada y la fecha de su última revisión.' . "\n\n";
	$o .= '- Autor y revisor: Pau Lobato, fundador y editor de Jubilómetro (' . $base . "/sobre-nosotros/).\n";
	$o .= '- Idioma: español (España). Ámbito: Seguridad Social y pensiones públicas españolas.' . "\n";
	$o .= '- ' . count( $posts ) . ' guías publicadas; última actualización: ' . ( $ultima ? wp_date( 'j \d\e F \d\e Y', $ultima ) : '' ) . ".\n";
	$o .= '- Cómo citar: «Jubilómetro» con enlace a la guía concreta. Las cifras son orientativas y no sustituyen la resolución del INSS.' . "\n\n";
	$o .= "## Sobre la web\n\n";
	foreach ( array( 'sobre-nosotros' => 'Quiénes somos', 'metodologia' => 'Metodología: cómo verificamos y calculamos', 'contacto' => 'Contacto', 'guias' => 'Todas las guías por tema', 'calculadoras' => 'Todas las calculadoras', 'datos' => 'Datos y estadísticas' ) as $slug => $txt ) {
		$o .= '- [' . $txt . '](' . $base . '/' . $slug . "/)\n";
	}
	$o .= "\n## Calculadoras\n\n";
	foreach ( (array) jm_data( 'calcs' ) as $c ) {
		$o .= '- [' . $c['name'] . '](' . $base . '/calculadoras/' . $c['slug'] . '/): ' . $c['desc'] . "\n";
	}
	$o .= '- [Calculadoras gratis para tu web](' . $base . "/calculadoras/para-tu-web/): código para insertar cualquiera de las calculadoras en otra web.\n";
	// Tablas de datos propios: las páginas hijas de /datos/
	$datos = get_page_by_path( 'datos' );
	$hijas = $datos ? get_pages( array( 'child_of' => $datos->ID, 'post_status' => 'publish', 'sort_column' => 'post_title' ) ) : array();
	if ( $hijas ) {
		$o .= "\n## Datos oficiales, actualizados cada mes\n\n";
		foreach ( $hijas as $h ) { $o .= $fmt( $h->ID ) . "\n"; }
	}
	$cats = (array) jm_data( 'cats' );
	foreach ( (array) jm_data( 'temas' ) as $slug ) {
		$lineas = array();
		foreach ( $posts as $p ) {
			$cat = get_the_category( $p->ID );
			if ( $cat && $cat[0]->slug === $slug ) { $lineas[] = $fmt( $p->ID ); }
		}
		if ( ! $lineas ) { continue; }
		$o .= "\n## " . ( isset( $cats[ $slug ]['name'] ) ? $cats[ $slug ]['name'] : $slug ) . "\n\n" . implode( "\n", $lineas ) . "\n";
	}
	set_transient( 'jm_llms_txt', $o, 12 * HOUR_IN_SECONDS );
	return $o;
}
add_action( 'save_post', function () { delete_transient( 'jm_llms_txt' ); } );

// Search Console: archivo de verificación de Google y direcciones antiguas de las páginas legales
// (otros nombres que Google encontró y daban 404) y guías fusionadas, con redirección permanente a las buenas.
add_action( 'init', function () {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtok( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), '?' ) : '';
	if ( '/google937ba0a9a16a45b8.html' === $uri ) {
		header( 'Content-Type: text/html; charset=utf-8' );
		echo 'google-site-verification: google937ba0a9a16a45b8.html';
		exit;
	}
	$viejas = array(
		'/politica-de-privacidad/' => '/politica-privacidad/',
		'/politica-de-privacidad'  => '/politica-privacidad/',
		'/politica-de-cookies/'    => '/politica-cookies/',
		'/politica-de-cookies'     => '/politica-cookies/',
	);
	// Guías fusionadas con otra (inc/data.json → "fusionadas"): la dirección vieja lleva para siempre a la nueva.
	$viejas = array_merge( $viejas, (array) jm_data( 'fusionadas' ) );
	if ( '/' !== substr( $uri, -1 ) && isset( $viejas[ $uri . '/' ] ) ) { $uri .= '/'; }
	if ( isset( $viejas[ $uri ] ) ) {
		wp_safe_redirect( home_url( $viejas[ $uri ] ), 301 );
		exit;
	}
}, 1 );

define( 'JM_INDEXNOW_KEY', '3337a9d98f536ce6049cb37171761901' );
add_action( 'init', function () {
	$uri = isset( $_SERVER['REQUEST_URI'] ) ? strtok( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), '?' ) : '';
	if ( '/llms.txt' === $uri ) {
		header( 'Content-Type: text/plain; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		echo jm_llms_txt(); // phpcs:ignore
		exit;
	}
	if ( '/' . JM_INDEXNOW_KEY . '.txt' === $uri ) {
		header( 'Content-Type: text/plain; charset=utf-8' );
		echo JM_INDEXNOW_KEY; // phpcs:ignore
		exit;
	}
}, 1 );

// IndexNow: se juntan las URL publicadas o cambiadas en la petición y se envían de una vez al terminar
function jm_indexnow_add( $urls ) {
	static $cola = null;
	if ( null === $cola ) {
		$cola = array();
		add_action( 'shutdown', function () use ( &$cola ) {
			if ( ! $cola ) { return; }
			wp_remote_post( 'https://api.indexnow.org/indexnow', array(
				'blocking' => false,
				'timeout'  => 3,
				'headers'  => array( 'Content-Type' => 'application/json; charset=utf-8' ),
				'body'     => wp_json_encode( array( 'host' => wp_parse_url( home_url(), PHP_URL_HOST ), 'key' => JM_INDEXNOW_KEY, 'keyLocation' => home_url( '/' . JM_INDEXNOW_KEY . '.txt' ), 'urlList' => array_values( array_unique( $cola ) ) ) ),
			) );
		} );
	}
	foreach ( (array) $urls as $u ) { $cola[] = $u; }
}
add_action( 'transition_post_status', function ( $new, $old, $post ) {
	if ( 'publish' !== $new || wp_is_post_revision( $post ) || ! in_array( $post->post_type, array( 'post', 'page' ), true ) ) { return; }
	jm_indexnow_add( get_permalink( $post ) );
}, 10, 3 );
// Una vez: todas las páginas publicadas, para que Bing tenga la web completa al día
add_action( 'init', function () {
	if ( 'v1' === get_option( 'jm_indexnow_todo' ) ) { return; }
	update_option( 'jm_indexnow_todo', 'v1', false );
	$ids = get_posts( array( 'post_type' => array( 'post', 'page' ), 'post_status' => 'publish', 'posts_per_page' => -1, 'fields' => 'ids', 'no_found_rows' => true ) );
	jm_indexnow_add( array_map( 'get_permalink', $ids ) );
}, 30 );
